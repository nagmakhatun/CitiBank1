
   function validate(frm){
	   
	   //empty error messages
	    document.getElementById("pnameErr").innerHTML="";
	    document.getElementById("pageErr").innerHTML="";
	   
	   //read form data
	   var name=frm.pname.value;
	   var age=frm.page.value;
	   
	   //written client side Validation logic
	   if(name==""){
		   document.getElementById("pnameErr").innerHTML="<b>Person name is required</b>";
		   frm.pname.focus();
		   return false;   
	   }
	   if(age==""){
		   document.getElementById("pageErr").innerHTML="<b>Person age is required</b>";
		   frm.page.focus();
		   return false;
	   }
	   else if(isNaN(age)){
		   document.getElementById("pageErr").innerHTML="<b>Person age must be numeric</b>";
		   frm.page.focus();
		   return false;
	   }
	   else if(age<=0||age>125){
		   document.getElementById("pageErr").innerHTML="<b>person age must be there between through 1 to 125</b>";
		   frm.page.focus();
		   return false;
	   }
	   frm.vflag.value="yes";
	   return true;
   }

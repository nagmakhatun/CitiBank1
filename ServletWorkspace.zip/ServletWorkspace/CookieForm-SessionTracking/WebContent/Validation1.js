
   function validate(frm){
	   
	   //empty error messages
	    document.getElementById("pnameErr").innerHTML="";
	    document.getElementById("fnameErr").innerHTML="";
	   
	   //read form data
	   var pname=frm.pname.value;
	   var fname=frm.fname.value;
	   
	   reWhiteSpace = new RegExp(/^\s+$/);


	     // Check for white space
	     if (reWhiteSpace.test(frm)) {
	          alert("Please Check Your Fields For Spaces");
	          return false;
	     }
	    
	
	   
	   //written client side Validation logic
	   if(pname==""){
		   document.getElementById("pnameErr").innerHTML="<b>Person name is required</b>";
		   frm.pname.focus();
		   return false;   
	   }
	   if(fname==""){
		   document.getElementById("fnameErr").innerHTML="<b>Person Father name is required</b>";
		   frm.fname.focus();
		   return false; 
	   }
	   
	   frm.vflag.value="yes";
	   return true;
   }

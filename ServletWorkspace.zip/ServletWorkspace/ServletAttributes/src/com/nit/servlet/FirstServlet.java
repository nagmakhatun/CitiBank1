package com.nit.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/firsturl")
public class FirstServlet extends HttpServlet {
	
   
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		PrintWriter pw=null;
		RequestDispatcher rd=null;
		HttpSession ses=null;
		ServletContext sc=null;
		
		//get writer
		pw=res.getWriter();
		
		//set Content type
		res.setContentType("text/html");
		
		//create request attribute
		req.setAttribute("attr1", "val1");
		
		//create Session Attribute;
		ses=req.getSession();
		ses.setAttribute("attr2","val2");
		
		//create ServletContext Attribute
		
		sc=getServletContext();
		sc.setAttribute("attr3", "val3");
		
		//read and display request attribute value
		pw.println("<br><b>(FirstServlet)req attribute(attr1) value:::"+req.getAttribute("attr1")+"</b>");
		
		//read and display Session attribute value
		pw.println("<br><b>(FirstServlet)session attribute(attr2) value:::"+ses.getAttribute("attr2")+"</b>");
		
		//read and display Session attribute value
		pw.println("<br><b>(FirstServlet)ServletContext attribute(attr3) value:::"+sc.getAttribute("attr3")+"</b>");
		
		
		//forward Request Second servlet
		rd=req.getRequestDispatcher("/secondurl");
		rd.forward(req, res);
		
		
		
		
	}

	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		doGet(req, res);
	}

}

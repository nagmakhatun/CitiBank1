package com.nit.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/sgsturl")
public class ITStateGSTServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter pw=null;
		ServletContext sc1,sc2=null;
		RequestDispatcher rd=null;
		
		String company=null,project=null,ptype=null;
		float cost=0.0f ,sgst=0.0f;
		
		//get PrintWriter
		pw=res.getWriter();
		//set ContentType
		res.setContentType("text/html");
		
		
		
		//read form data
		company=req.getParameter("company");
		ptype=req.getParameter("ptype");
		project=req.getParameter("project");
		cost=Float.parseFloat(req.getParameter("cost"));
		
		//calculate State GST
		if(ptype.equalsIgnoreCase("product"))
			sgst=cost*0.12f;
		else if(ptype.equalsIgnoreCase("service"))
			sgst=cost*0.1f;
		else if(ptype.equalsIgnoreCase("startup"))
			sgst=cost*0.03f;
		
		//display Details
		pw.println("<h1 style='color:green;text-align:center'>GST Info</h1>");
		pw.println("<br><b> Company Name::"+company+"<b>");
		pw.println("<br><b> Project Name::"+project+"<b>");
		pw.println("<br><b> Project Type::"+ptype+"<b>");
		pw.println("<br><b> Cost::"+cost+"<b>");
		pw.println("<br><b><i> State GST::"+sgst+"<i><b>");
		
		//get servlet context of source servlet
		sc1=getServletContext();
		
		//get Foreign Context object of CentralGSTApp
		sc2=sc1.getContext("/CentralGSTApp");
		
		//Communication with Destination servlet CentralGSTApp ServletContext
		rd=sc2.getRequestDispatcher("/cgsturl");
		rd.include(req,res);
		
		//add Hyperlink
		pw.println("<br><br><a href='input.html'> Home </a>");
		
		//close stream
		pw.close();
		
		
		
		
		
		
		
		
	}

	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		doGet(req, res);
	}

}

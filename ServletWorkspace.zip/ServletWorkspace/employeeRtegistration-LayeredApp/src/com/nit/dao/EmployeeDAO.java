package com.nit.dao;

import com.nit.bo.EmployeeBO;

public interface EmployeeDAO {
	
	public  int  insert(EmployeeBO bo)throws Exception;

}

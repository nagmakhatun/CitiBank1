package com.nit.service;

import com.nit.dto.EmployeeDTO;

public interface EmployeeMgmtService {
   public  String  registerEmployee(EmployeeDTO dto)throws Exception;
}

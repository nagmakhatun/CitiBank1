//MarriageServlet.java
package com.nt.servlet;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;


public class MarriageServlet extends HttpServlet {
	@Override
	public void doGet(HttpServletRequest req,HttpServletResponse res)
		     throws ServletException,IOException{
		PrintWriter pw=null;
		String name=null;
		String tage=null;
		int age=0;
		String tgender=null;
		//get printwriter
		pw=res.getWriter();

		//set Content Type
		res.setContentType("text/html");
        
		//get request parameter values(form data)
		name=req.getParameter("pname");
		tage=req.getParameter("page");
		age=Integer.parseInt(tage);
		tgender=req.getParameter("pgender");

		//write Business logic
		if(tgender.equalsIgnoreCase("male")){
			if(age<21){
			pw.println("<h1 style='color:red;text-align:center'>"+name+":: U r not eligible for Marriage </h1>");
		    }else{
			pw.println("<h1 style='color:green;text-align:center'>"+name+":: U r eligible for Marriage </h1>");
            }
		} else if (tgender.equalsIgnoreCase("female")){
			if(age<18){
			pw.println("<h1 style='color:red;text-align:center'>"+name+":: U r not eligible for Marriage </h1>");
		    }else{
			pw.println("<h1 style='color:green;text-align:center'>"+name+":: U r eligible for Marriage </h1>");
            }

		}
		//insert hyperlink
		pw.println("<a href='http://localhost:1234/MarriageApp/input1.html'><img src='marriage.png'></a>");

		//close stream
		pw.close();
	}//doGet(-,-)
}//close class

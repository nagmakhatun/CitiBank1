//EmployeeSearchServlet.java
package com.nit.servlet;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;  //jdbc api

public class EmployeeSearchServlet extends HttpServlet{
	private static final String GET_EMP_DETAILS_BY_NO="SELECT EMPNO,ENAME,JOB,SAL,DEPTNO FROM EMP WHERE EMPNO=?";
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException {
		PrintWriter pw=null;
		int eno=0;
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		ServletContext sc=null;
		String driver=null,url=null,dbuser=null,dbpwd=null;

		try{

			//get PrintWriter
			pw=res.getWriter();

			//set response ContentType
			res.setContentType("text/html");

			//read form data
			eno=Integer.parseInt(req.getParameter("eno"));
			
			//get ServletContext object
			sc=getServletContext();
			
			 driver = sc.getInitParameter("driver");
			 url = sc.getInitParameter("url");
			 dbuser = sc.getInitParameter("dbuser");
			 dbpwd = sc.getInitParameter("dbpwd");

			//register JDBC driver
			Class.forName(driver);

			//Establish the Connection
			con=DriverManager.getConnection(url,dbuser,dbpwd);

			//Create PreparedStatement having pre-compiled query
			ps=con.prepareStatement(GET_EMP_DETAILS_BY_NO);

			//Set Query param values
			ps.setInt(1,eno);

			//execute the Query
			rs=ps.executeQuery();

			//process the ResultSet object
			if (rs.next()){
				pw.println("<h1 style='color:green'> Employee Details are:::</h1>");
				pw.println("<b> Empno::</b>"+rs.getInt(1)+"<br>");
				pw.println("<b> EName::</b>"+rs.getString(2)+"<br>");
				pw.println("<b> Job::</b>"+rs.getString(3)+"<br>");
				pw.println("<b> Salary::</b>"+rs.getFloat(4)+"<br>");
				pw.println("<b> Deptno::</b>"+rs.getInt(5)+"<br>");

			} else {
				pw.println("<h1 style='colo:blue'>Employee Not Found </h1>");
			}
			
			 //home hyperlink
			 pw.println("<br><br><a href='input.html'>home</a>");
		}//try
		 catch(SQLException se){
			 se.printStackTrace();
			 pw.println("<h1 style='color:red'>Internal DB Problem</h1>");
		 }
		 catch(ClassNotFoundException cnf){
			 cnf.printStackTrace();
			 pw.println("<h1 style='color:red'>Internal Problem</h1>");
		 }
		 catch(Exception e){
			 e.printStackTrace();
			 pw.println("<h1 style='color:red'>Internal Problem</h1>");
		 }

		 finally{
			 //close jdbc objects
			 try{
				 if(rs!=null){
					 rs.close();
				 }
			 }
			catch(SQLException se){
				se.printStackTrace();
			 }
			 
			try{
				 if(ps!=null){
					 ps.close();
				 }
			}
			catch(SQLException se){
				 se.printStackTrace();
			 }
			
			try{
				 if(con!=null){
					 con.close();
				 }
			}
			catch(SQLException se){
				 se.printStackTrace();
			}
			
			try{
				 if(pw!=null){
					 pw.close();
				 }
			}
		   catch(Exception e){
			    e.printStackTrace();
			}
			
		
		}//finally
	}//doGet

	public void doPost(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException {
		doGet(req,res);
	}
}

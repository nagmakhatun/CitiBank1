package com.nit.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class TestServlet extends HttpServlet {
	
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TestServlet() {
    	System.out.println("TestServlet Constructor::TestServlet()");
    	// WE CANNOT ACCESS(INITIALIZE) ServletConfig and ServletContext INSIDE CONSTRUCTOR
    	//ServletConfig cg=getServletConfig();
    	//ServletContext sc=getServletContext();  NPE
    	//System.out.println("dbuser init param value::"+cg.getInitParameter("dbuser"));
    	//System.out.println("dbuser context param value::"+sc.getInitParameter("dbuser"));
        
    }

	
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter pw=null;
		ServletConfig cg=null;
		ServletContext sc=null;
		//get printWriter
		pw=res.getWriter();
		//set ContentType
		res.setContentType("text/html");
		
		//get Access ServletConfig obj
		cg=getServletConfig();
		
		//get Access ServletContext obj
		sc=getServletContext();
		
				
		pw.println("<br> dbuser init param value::"+cg.getInitParameter("dbuser"));
		
		pw.println("<br><br><br><b> Details Using ServletContext object::</b><br><br>");
		pw.println("<br> Server INfo::"+sc.getServerInfo());
		pw.println("<br> Servlet Context name::"+sc.getServletContextName());
		pw.println("<br> ServletContext class Name::"+sc.getClass());
		pw.println("<br>ServletContext path::"+sc.getContextPath());
		pw.println("<br>Server Effective major version::"+sc.getEffectiveMajorVersion());
		pw.println("<br>Server Minor Version::"+sc.getEffectiveMinorVersion());
		pw.println("<br>Server major version::"+sc.getMajorVersion());
        pw.println("<br>MIME type of input.html::"+sc.getMimeType("input.html"));
        pw.println("<br>Path of input.html::"+sc.getRealPath("/input.html"));
        pw.println("<br>Path of web root folder::"+sc.getContextPath());
        		
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doGet(req, res);
	}

}

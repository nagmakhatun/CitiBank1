package com.nit.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/secondurl")
public class SecondServlet extends HttpServlet {
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		PrintWriter pw=null;
		String pname=null,fname=null,ms=null;
		String f2val1=null,f2val2=null;
		//get Writer
		pw=res.getWriter();
		
		//set contentType
		res.setContentType("text/html");
		
		//read form data
		pname=req.getParameter("pname");
		fname=req.getParameter("fname");
		ms=req.getParameter("ms");
		
		//read form/req2 data
		
		f2val1=req.getParameter("f2t1");
		f2val2=req.getParameter("f2t2");
		
		//display dynamic webpage having both form/req1 data and form2/req2 data...
		pw.println("<h1 style='color:red;text-align:center'>Result page</h1>");
		pw.println("<br>form1/req1 data::"+pname+"..."+fname+"..."+ms);
		pw.println("<br>form2/req2 data::"+f2val1+"..."+f2val2);
		
		//add hyperlink
		pw.println("<br><br><a href='input.html'>home</a>");
		
		//close stream
		pw.close();
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		doGet(req, res);
	}

}

package com.nit.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FormServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter pw=null;
		String name=null,gender=null,ms=null, addr=null, qlfy=null, email=null, fb=null,dob=null, fweek=null, mob=null, fcolor=null,crs[]=null,hb[]=null;
		int age=0, salary=0;
		long cno=0;
		//get PrintWriter
		pw=res.getWriter();
		
		//set ContentType
		res.setContentType("text/html");
		
		//read  form data
		name=req.getParameter("pname");
		age=Integer.parseInt(req.getParameter("page"));
		gender=req.getParameter("gender");
		ms=req.getParameter("ms");
		cno=Long.parseLong(req.getParameter("cno"));
		email=req.getParameter("email");
		fb=req.getParameter("fb");
		fweek=req.getParameter("fweek");
		fcolor=req.getParameter("fcolor");
		mob=req.getParameter("mob");
		salary=Integer.parseInt(req.getParameter("salary"));
		qlfy=req.getParameter("qlfy");
		crs=req.getParameterValues("crs");
		hb=req.getParameterValues("hb");
		
		//Wrire Request Processing Logic
		if (gender.equalsIgnoreCase("M"))
			if (age<=5)
				pw.println("Master."+name+"u r baby boy");
			else if (age<=12)
				pw.println("Master./Mr."+name+"u r kid");
			else if(age<=19)
				pw.println("Mr."+name+"u r teenage boy");
			else if (age<=35)
				pw.println("Mr."+name+"u r young man");
			else if (age<=50)
				pw.println("Mr."+name+"u r middle aged man");
			else
				pw.println("Mr."+name+"u r old man");
		//close if
		else if(gender.equalsIgnoreCase("F"))
			if (age<=5)
				pw.println("Master."+name+"u r baby girl");
			else if (age<=12)
				pw.println("Master./Miss"+name+"u r little girl");
			else if(age<=19)
				if (ms.equalsIgnoreCase("married"))
				     pw.println("Mrs."+name+"u r teenage girl");
				else
					pw.println("Miss"+name+"u r teenage girl");
			else if (age<=35)
				if (ms.equalsIgnoreCase("married"))
				     pw.println("Mrs."+name+"u r young women");
				else
					pw.println("Miss"+name+"u r young lady");
			else if (age<=50)
				if (ms.equalsIgnoreCase("married"))
				     pw.println("Mrs."+name+"u r middle-aged women");
				else
					pw.println("Miss"+name+"u r middle-aged women");
			else
				if (ms.equalsIgnoreCase("married"))
				     pw.println("Mrs."+name+"u r old women");
				else
					pw.println("Miss"+name+"u r old women");
		//close of else if
		
		//Display Data
		pw.println("<b> name::"+name +"<br>");
		pw.println("<b> age::"+age +"<br>");
		pw.println("<b> gender::"+gender +"<br>");
		pw.println("<b> Address::"+addr +"<br>");
		pw.println("<b> Contact No.::"+cno +"<br>");
		pw.println("<b> Marital Status::"+ms +"<br>");
		pw.println("<b> Email Id::"+email +"<br>");
		pw.println("<b> Facebook Url::"+fb +"<br>");
		pw.println("<b> D.O.B::"+dob +"<br>");
		pw.println("<b> Fav. Weel::"+fweek+"<br>");
		pw.println("<b> Fav. color::"+fcolor +"<br>");
		pw.println("<b> Month of Birth::"+mob +"<br>");
		pw.println("<b> Salary::"+salary +"<br>");
		pw.println("<b> Qualification::"+qlfy +"<br>");
		pw.println("<b> Courses::"+Arrays.deepToString(crs) +"<br>");
		pw.println("<b> Hobbies::"+Arrays.deepToString(hb) +"<br>");
		
		//add hyperlink
		pw.println("<br> <a href='form.html'> Home<br>");
		
		//close Stream
		pw.close();
				
	}//doGet(-,-)
	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doGet(req,res);
	}//doPost
	

}

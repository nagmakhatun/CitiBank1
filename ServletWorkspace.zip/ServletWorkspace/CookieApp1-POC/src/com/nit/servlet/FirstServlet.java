package com.nit.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/firsturl")
public class FirstServlet extends HttpServlet {
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter pw=null;
		Cookie cookie1=null,cookie2=null,cookie3=null,cookie4=null;
		//get writer
		pw=res.getWriter();
		//set ContentType
		res.setContentType("text/html");
		
		//create cookie
		cookie1= new Cookie("jsg","jharsuguda");
		cookie2= new Cookie("bbs","Bhubaneswar");
		res.addCookie(cookie1);//In-Memory cookie
		res.addCookie(cookie2);//In-Memory cookie
		
		
		cookie3= new Cookie("blr","Bangalore");
		cookie4= new Cookie("hyd","Hyderabad");
		res.addCookie(cookie3);//Persistent cookie
		res.addCookie(cookie4);//Persistent cookie
		//set MaxAge
		cookie3.setMaxAge(180);
		cookie4.setMaxAge(240);
		
				
		pw.println("<h4>Cookies created and added response.....</h4>");
	}

	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		doGet(req, res);
	}

}

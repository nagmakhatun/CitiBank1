package com.nit.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/secondurl")
public class SecondServlet extends HttpServlet {
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter pw=null;
		Cookie cookie[]=null;
		//get writer
		pw=res.getWriter();
		//set ContentType
		res.setContentType("text/html");
		
		//get cookies
		cookie=req.getCookies();
		pw.println("<h1 style='color:red;text-align:center'>Cookies are added</h1>");
		for(Cookie ck:cookie) {
			
			pw.println("<table border='1' bgcolor='cyan'>");
			pw.println("<tr><th>Cookie Name</th><th>Cookie Value</th><th>Cookie path</th><th>Cookie MaxAge</th><tr>");
			pw.println("<tr><td>"+ck.getName()+"</td><td>"+ck.getValue()+"</td><td>"+ck.getPath()+"</td><td>"+ck.getMaxAge()+"</td></tr>");
			pw.println("</table>");
		}
		 
		
		pw.close();
		
	}

	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		doGet(req, res);
	}

}

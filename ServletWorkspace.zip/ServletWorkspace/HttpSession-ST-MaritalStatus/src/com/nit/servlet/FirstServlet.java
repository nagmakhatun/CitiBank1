package com.nit.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;




@WebServlet("/firsturl")
public class FirstServlet extends HttpServlet {
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter pw=null;
		String pname=null,fname=null,ms=null,gender=null;
		//Cookie ck1=null,ck2=null,ck3=null,ck4=null;
		HttpSession ses=null;
		String vstatus=null;
		//get Writer
		pw=res.getWriter();
		
		//set contentType
		res.setContentType("text/html");
		
		//read form data
		pname=req.getParameter("pname");
		fname=req.getParameter("fname");
		gender=req.getParameter("gender");
		ms=req.getParameter("ms");
		vstatus=req.getParameter("vflag");
		
		//create and locate HttpSession Object
		ses=req.getSession(true);
		
		//setAttribute value to HttpSession object
		ses.setAttribute("pname", pname);
		ses.setAttribute("fname", fname);
		ses.setAttribute("gender", gender);
		ses.setAttribute("ms", ms);
		
		if(vstatus.equalsIgnoreCase("no")){
			
			System.out.println("Server side Form Validation start");			
			if (pname.isEmpty()||pname.contains("-")||pname.contains("@")||pname.equals("")){
			    pw.println("<h4 style='color:red'>person name shouldn't contain any space in between words or any special character Else u will get ArrayIndexOutOfBoundException</h4>");
			    return;
			}
			if (fname.isEmpty()||fname.contains("-")||fname.contains("@")||fname.equals("")){
			    pw.println("<h4 style='color:red'>person's father name shouldn't contain any space in between words or any special character Else u will get ArrayIndexOutOfBoundException</h4>");
			    return;
			} 
		}
			System.out.println("Server side Form Validation end");
	 
		
		//generate Dynamic web page form based on Marital Status
		if(ms.equalsIgnoreCase("single")) {
			pw.println("<h1 style='color:red;text-align:center'>Provide Bachelor Life Related Data</h1>");
			pw.println("<form action='secondurl' method='post'>");
			pw.println("<table bgcolor='orange' align='center'>");
			pw.println("<tr><td>when do you want to get marry::</td><td><input type='text' name='f2t1'></td></tr>");
			pw.println("<tr><td>why do you want to get marry::</td><td><input type='text' name='f2t2'></td></tr>");
			pw.println("<tr><td ><input type='submit' value='Register'></td><td ><input type='reset' value='Reset'></td></tr>");
			pw.println("</table>");
			pw.println("</form>");
		} else {
			pw.println("<h1 style='color:red;text-align:center'>Provide Bachelor Life Related Data</h1>");
			pw.println("<form action='secondurl' method='post'>");
			pw.println("<table bgcolor='pink' align='center'>");
			pw.println("<tr><td>Spouse Name::</td><td><input type='text' name='f2t1'></td></tr>");
			pw.println("<tr><td>No. of Kids::</td><td><input type='text' name='f2t2'></td></tr>");
			pw.println("<tr><td><input type='submit' value='Register'></td><td ><input type='reset' value='Reset'></td></tr>");
			pw.println("</table>");
			pw.println("</form>");
			
		}
		
		pw.println("<b><br><br>get HttpSession obj Id:::"+ses.getId()+"</b>");
		
		long milisec=ses.getCreationTime();
		Date d=new Date(milisec);
		pw.println("<b><br><br>creatime time:::"+d+"</b>");
		
		long lat=ses.getLastAccessedTime();
		Date d1=new Date(lat);
		pw.println("<b><br><br>Get Last Accessed time:::"+d1+"</b>");
		
	
		boolean b=ses.isNew();
		pw.println("<b><br><br>Wheather Session is New or old:::"+b+"</b>");
		
		/*
		 * //create and add Cookie ck1=new Cookie("pname", pname); ck2=new
		 * Cookie("fname", fname); ck3=new Cookie("gender", gender); ck4=new
		 * Cookie("ms", ms);
		 * 
		 * res.addCookie(ck1); res.addCookie(ck2); res.addCookie(ck3);
		 * res.addCookie(ck4);
		 */
		
		
		
		//close stream
		pw.close();
			
		
		
	}

	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		doGet(req, res);
	}

}

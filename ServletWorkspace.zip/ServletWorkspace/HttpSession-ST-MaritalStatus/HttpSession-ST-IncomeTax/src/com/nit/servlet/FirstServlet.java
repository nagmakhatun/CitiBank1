package com.nit.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/firsturl")
public class FirstServlet extends HttpServlet {
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter pw=null;
		String pname=null,fname=null,gender=null;
		HttpSession ses=null;
		//get Writer
		pw=res.getWriter();
		
		//set contentType
		res.setContentType("text/html");
		
		//read form1/req1 data
		pname=req.getParameter("pname");
		fname=req.getParameter("fname");
		gender=req.getParameter("gender");
		
		//create or locate HttpSession object
		ses=req.getSession(true);
		
		//Write form1/req1 data to Session object as setAttribute
		ses.setAttribute("pname",pname);
		ses.setAttribute("fname",fname);
		ses.setAttribute("gender",gender);
		
		
		
		//generate Dynamic web page form 
		
			pw.println("<h1 style='color:red;text-align:center'>Provide Income Details</h1>");
			pw.println("<form action='secondurl' method='post'>");
			pw.println("<table bgcolor='orange' align='center'>");
			pw.println("<tr><td>Income::</td><td><input type='text' name='income'></td></tr>");
			pw.println("<tr><td>Tax::</td><td><input type='text' name='tax'></td></tr>");
			pw.println("<tr><td colspan='2' align='center'><input type='submit' value='Register'></td></tr>");
			pw.println("</table>");
			pw.println("</form>");
			
			
		pw.println("<b><br><br>get HttpSession obj Id:::"+ses.getId()+"</b>");
		
		long ms=ses.getCreationTime();
		Date d=new Date(ms);
		pw.println("<b><br><br>creatime time:::"+d+"</b>");
		
		long lat=ses.getLastAccessedTime();
		Date d1=new Date(lat);
		pw.println("<b><br><br>Get Last Accessed time:::"+d1+"</b>");
		
	
		boolean b=ses.isNew();
		pw.println("<b><br><br>Wheather Session is New or old:::"+b+"</b>");
		
		//close stream
		pw.close();
			
		
		
	}

	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		doGet(req, res);
	}

}

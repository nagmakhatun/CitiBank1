package com.nit.listener;

import java.util.Date;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

public class SessionDurationAnalyzerListener implements HttpSessionListener {
	
	private long start=0,end=0;
	
	@Override
	public void sessionCreated(HttpSessionEvent se) {
		System.out.println("SessionDurationAnalyzerListener.sessionCreated()");
		HttpSession ses=null;
		ServletContext sc=null;
		
		start=System.currentTimeMillis();
		
		//get ServletContext obj
		sc=se.getSession().getServletContext();
		
		//get session object
		ses=se.getSession();
		
		sc.log("Session Id:::"+ses.getId()+" Session started at "+new Date());
	}
	
	@Override
	public void sessionDestroyed(HttpSessionEvent se) {
		System.out.println("SessionDurationAnalyzerListener.sessionDestroyed()");
		HttpSession ses=null;
		ServletContext sc=null;
		
		//get ServletContext obj
		sc=se.getSession().getServletContext();
		
		//get Session object
		ses=se.getSession();
				
		end=System.currentTimeMillis();
		
		sc.log("Session Id:::"+ses.getId()+" Session ended at "+new Date());
		
		sc.log("Session Id:::"+ses.getId()+"  Session duration is::: "+(end-start)+"ms ");
	}

}

package com.nit.listener;

import java.util.Date;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

@WebListener
public class WebApplicationMonitoringListener implements ServletContextListener {
	private long start=0,end=0;
	
	@Override
	public void contextInitialized(ServletContextEvent sce) {
		System.out.println("WebApplicationMonitoringListener.contextInitialized()");
		ServletContext sc=null;
		
		start=System.currentTimeMillis();
		
		//get SevletContext object
		sc=sce.getServletContext();
		sc.log(sc.getContextPath()+" id deployed/restarted/reloaded at:::"+new Date());
		
	}
	
	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		System.out.println("WebApplicationMonitoringListener.contextDestroyed()");
		ServletContext sc=null;
		end=System.currentTimeMillis();
		
		//get SevletContext object
		sc=sce.getServletContext();
		sc.log(sc.getContextPath()+" id deployed/restarted/reloaded at:::"+new Date());
		sc.log(sc.getContextPath()+" duration is:::"+(end-start)+"ms");
		
	}

}

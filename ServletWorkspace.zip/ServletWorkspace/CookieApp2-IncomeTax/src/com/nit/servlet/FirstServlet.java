package com.nit.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/firsturl")
public class FirstServlet extends HttpServlet {
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter pw=null;
		String pname=null,fname=null,gender=null;
		Cookie ck1=null,ck2=null,ck3=null;
		//get Writer
		pw=res.getWriter();
		
		//set contentType
		res.setContentType("text/html");
		
		//read form data
		pname=req.getParameter("pname");
		fname=req.getParameter("fname");
		gender=req.getParameter("gender");
		
		//generate Dynamic web page form 
		
			pw.println("<h1 style='color:red;text-align:center'>Provide Income Details</h1>");
			pw.println("<form action='secondurl' method='post'>");
			pw.println("<table bgcolor='orange' align='center'>");
			pw.println("<tr><td>Income::</td><td><input type='text' name='income'></td></tr>");
			pw.println("<tr><td>Tax::</td><td><input type='text' name='tax'></td></tr>");
			pw.println("<tr><td colspan='2' align='center'><input type='submit' value='Register'></td></tr>");
			pw.println("</table>");
			pw.println("</form>");
		
		
		//create and add Cookie
		ck1=new Cookie("pname",pname);
		ck2=new Cookie("fname",fname);
		ck3=new Cookie("gender",gender);
		
		
		res.addCookie(ck1);
		res.addCookie(ck2);
		res.addCookie(ck3);
		
		
		
		
		//close stream
		pw.close();
			
		
		
	}

	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		doGet(req, res);
	}

}

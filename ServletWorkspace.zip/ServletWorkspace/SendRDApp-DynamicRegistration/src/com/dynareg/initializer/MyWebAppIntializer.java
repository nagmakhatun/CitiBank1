package com.dynareg.initializer;

import java.util.Set;

import javax.servlet.ServletContainerInitializer;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import com.nit.servlet.SearchServlet;

public class MyWebAppIntializer implements ServletContainerInitializer {
	public MyWebAppIntializer() {
		System.out.println("MyWebAppIntializer.MyWebAppIntializer()");
	}

	@Override
	public void onStartup(Set<Class<?>> set, ServletContext sc) throws ServletException {
		System.out.println("MyWebAppIntializer.onStartup()");
		
		SearchServlet servlet=null;
		ServletRegistration.Dynamic dyna=null;
		
		//create our servlet class object
		servlet=new SearchServlet();
		
		//register servlet comp
		dyna=sc.addServlet("search", servlet);
		
		//map with url pattern
		dyna.addMapping("/searchurl");
		
		//enable loadon start-up
		dyna.setLoadOnStartup(2);
		
		

	}

}

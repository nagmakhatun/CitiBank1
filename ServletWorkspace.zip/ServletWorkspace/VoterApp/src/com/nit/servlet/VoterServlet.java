package com.nit.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class VoterServlet extends HttpServlet {
	
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter pw=null;
		String name=null ,tage=null;
		int age=0;
		
		//get printwriter
		pw=res.getWriter();
		
		//set ContentType
		res.setContentType("text/html");
		
		//read form data
		name=req.getParameter("name");
		tage=req.getParameter("page");
		
		if (age>=18) {
			pw.println("<h1 style='color:green;text-align:center'>Miss/Mr/Mrs. "+name +" U r eligible for voting"+"</h1>");
		} else {
			pw.println("<h1 style='color:red;text-align:center'>Miss/Mr/Mrs. "+name +" U r not eligible for voting"+"</h1>");

		}
		
		pw.println("<br><a href='voter.html'> <img src='voting.png' height='50px' width='50px'> </a>");
		
		pw.close();
	}
	
	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doGet(req,res);
	}

}

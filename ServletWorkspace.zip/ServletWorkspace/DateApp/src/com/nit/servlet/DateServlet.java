package com.nit.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/dateurl")
public class DateServlet extends GenericServlet {
	@Override
	 public void service(ServletRequest req,ServletResponse res)throws ServletException,IOException{
		PrintWriter pw=null;
		Date d=null;
		
		//get writer
		pw=res.getWriter();
		
		//set ContentType
		res.setContentType("text/html");
		
		d=new Date(01, 05, 2020);
		pw.println("<h1 style='color:red;text-align:center'>Date and Time ::"+new java.util.Date()+"</h1><br><br>");
		pw.println("<h1 style='color:red;text-align:center'> Date is:::"+d.toGMTString()+"</h1><br>");
		pw.println("<h1 style='color:red;text-align:center'> Date is:::"+d.toLocalDate()+"</h1><br>");
		pw.println("<h1 style='color:red;text-align:center'> Date is:::"+d.toLocaleString()+"</h1><br>");
		pw.println("<h1 style='color:red;text-align:center'> Date is:::"+d.toString()+"</h1><br>");
		pw.println("<h1 style='color:red;text-align:center'> Date is:::"+d.getDate()+"</h1><br>");
		
		pw.close();
		


	}
	
}

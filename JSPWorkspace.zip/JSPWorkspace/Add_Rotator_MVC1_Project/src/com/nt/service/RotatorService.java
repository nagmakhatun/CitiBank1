package com.nt.service;

import java.util.Random;
import java.util.concurrent.CountDownLatch;

public class RotatorService {
	private String images[]=new String[] {"images/lalchand.jpg","images/malabar.jpg","images/kalyan.jpg"
			                               ,"images/caratelane.jpg","images/pcjewellers.jpg",
			                                 "images/tanishq.jpg"};
	
	private String links[]=new String[] {"https://www.tanishq.co.in/"
			                              ,"https://www.kalyanjewellers.net/"
			                              ,"https://www.caratlane.com/"
			                              ,"https://www.pcjeweller.com/"
			                              ,"https://www.malabargoldanddiamonds.com/"
			                              ,"http://lalchandgroup.com/"};
	
	private int counter=0;
	
	public void nextAdvertisement() {
		counter=new Random().nextInt(6);
	}
	
	public String getLinks() {
		return links[counter];
		
	}
	
	public String getImages() {
		return images[counter];
	}

}

package com.nt.tags;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class MessageTag extends TagSupport  {
	
	@Override
	public int doStartTag() throws JspException {
		System.out.println("MessageTag.doStartTag()");
		JspWriter out=null;
		
		out=pageContext.getOut();
		
		try {
			out.println("<h1 style='color:red'>Prime Numbers are::</h1>");
		}
		catch(IOException ioe) {
			ioe.printStackTrace();
		}
		
		return SKIP_BODY;
	}
	
	@Override
	public int doEndTag() throws JspException {
		System.out.println("MessageTag.doEndTag()");
		return EVAL_PAGE;
	}

}

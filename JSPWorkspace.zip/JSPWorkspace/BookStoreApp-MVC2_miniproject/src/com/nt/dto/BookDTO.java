package com.nt.dto;

import java.io.Serializable;

public class BookDTO implements Serializable {
	private static final long serialVersionUID=1L;
	private int serialNo;
	private int bookId;
	private String bookName;
	private String author;
	private float price;
	private String publisher;
	private String status;
	private String category;

}

package com.nt.service;

import com.nt.dto.EmployeeDTO;

public class SalaryReportManagementServiceImpl implements SalaryReportManagementService {

	public SalaryReportManagementServiceImpl() {
		System.out.println("SalaryReportManagementServiceImpl:0-param constructor");
	}
	@Override
	public void generateReport(EmployeeDTO dto) {
		double grossSalary=0.0,netSalary=0.0;
		
		grossSalary=dto.getBasicSal()+(dto.getBasicSal()*0.4);
		netSalary=grossSalary-(grossSalary*0.15);
		
		//set result to DTO
		dto.setGrossSal(grossSalary);
		dto.setNetSal(netSalary);

	}

}

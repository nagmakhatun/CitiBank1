package com.nt.dto;

import java.io.Serializable;

public class EmployeeDTO implements Serializable {
	private String ename;
	private String addrs;
	private double basicSal;
	private double netSal;
	private double grossSal;
	
	public EmployeeDTO() {
		System.out.println("EmployeeBean::0-param onstructor");
	}
	

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getAddrs() {
		return addrs;
	}

	public void setAddrs(String addrs) {
		this.addrs = addrs;
	}

	public double getBasicSal() {
		return basicSal;
	}

	public void setBasicSal(double basicSal) {
		this.basicSal = basicSal;
	}
	
	public double getNetSal() {
		return netSal;
	}


	public void setNetSal(double netSal) {
		this.netSal = netSal;
	}


	public double getGrossSal() {
		return grossSal;
	}


	public void setGrossSal(double grossSal) {
		this.grossSal = grossSal;
	}


	
	
	


	
	
	

}

package com.nt.bean;

public class CustomerBean {
	private int cNo;
	private String cName;
	private String addr;
	private double billAmt;
	
	public CustomerBean() {
		System.out.println("CustomerBean::0-param constructor");
	}

	public int getcNo() {
		System.out.println("CustomerBean.getcNo()");
		return cNo;
	}

	public void setcNo(int cNo) {
		System.out.println("CustomerBean.setcNo()");
		this.cNo = cNo;
	}

	public String getcName() {
		System.out.println("CustomerBean.getcName()");
		return cName;
	}

	public void setcName(String cName) {
		System.out.println("CustomerBean.setcName()");
		this.cName = cName;
	}

	public String getAddr() {
		System.out.println("CustomerBean.getAddr()");
		return addr;
	}

	public void setAddr(String addr) {
		System.out.println("CustomerBean.setAddr()");
		this.addr = addr;
	}

	public double getBillAmt() {
		System.out.println("CustomerBean.getBillAmt()");
		return billAmt;
	}

	public void setBillAmt(double billAmt) {
		System.out.println("CustomerBean.setBillAmt()");
		this.billAmt = billAmt;
	}
	
	

}

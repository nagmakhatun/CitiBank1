package com.nk.factory;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import com.nk.comp.BlueDartCourier;
import com.nk.comp.Courier;
import com.nk.comp.DTDCCourier;
import com.nk.comp.FirstFlightCourier;
import com.nk.comp.Flipkart;

public class FlipkartFactory {
	private  static Properties props;
	
	static {
		InputStream is=null;
		try {
			is=new FileInputStream("src/com/nk/common/info.properties");
			props=new Properties();
			props.load(is);
		} 
		catch (FileNotFoundException e) {
			e.printStackTrace();
		} 
		catch (IOException ioe) {
			ioe.printStackTrace();
		}
		
	}
	
	public static Flipkart getInstance() throws Exception {
		Flipkart fkrt=null;
		Courier courier=null;
		
		//
		courier=(Courier) Class.forName(props.getProperty("sdp.dependents")).newInstance();

		//create target class object
		fkrt=new Flipkart();
		
		//assign dependent class to target class
		fkrt.setCourier(courier);
		
		return fkrt;
	}

}

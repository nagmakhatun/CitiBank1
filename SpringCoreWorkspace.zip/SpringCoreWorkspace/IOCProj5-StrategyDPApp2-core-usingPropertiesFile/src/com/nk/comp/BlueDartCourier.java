package com.nk.comp;

public final class BlueDartCourier implements Courier {
	
	public BlueDartCourier() {
		System.out.println("BlueDartCourier::0-param constructor");
	}

	@Override
	public String deliver(int orderid) {
		System.out.println("BlueDartCourier.deliver()");
		
		return "BlueDart::Ur flipkart order having orderid"+orderid+" has been delivered successfully by our courier service";
	}

}

package com.nk.test;

import com.nk.comp.Flipkart;
import com.nk.factory.FlipkartFactory;

public class StrategyDPTest {
	
	public static void main(String[] args) {
		Flipkart fkrt=null;
		try {
			fkrt=FlipkartFactory.getInstance();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(fkrt.shopping(new String[] {"Dress","makeup Accesories","Bangles","superman chaddi"}, 
				                                                            new float[] {5000,8000,500,800}
		                                                                  )
				                              );
	}

}

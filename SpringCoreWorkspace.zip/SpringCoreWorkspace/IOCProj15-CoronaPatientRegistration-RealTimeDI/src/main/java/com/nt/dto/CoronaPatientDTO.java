package com.nt.dto;

import java.io.Serializable;

public class CoronaPatientDTO implements Serializable {
	private String pname;
	private String padd;
	private String stage;
	private int days_at_hospital;
	private float billAmt;
	
	//setters & getters
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPadd() {
		return padd;
	}
	public void setPadd(String padd) {
		this.padd = padd;
	}
	public String getStage() {
		return stage;
	}
	public void setStage(String stage) {
		this.stage = stage;
	}
	public int getDays_at_hospital() {
		return days_at_hospital;
	}
	public void setDays_at_hospital(int days_at_hospital) {
		this.days_at_hospital = days_at_hospital;
	}
	public float getBillAmt() {
		return billAmt;
	}
	public void setBillAmt(float billAmt) {
		this.billAmt = billAmt;
	}
	
	

}

package com.nt.controller;

import com.nt.dto.CoronaPatientDTO;
import com.nt.service.CoronaPatientMgmtService;
import com.nt.vo.CoronaPatientVO;

public final class MainController {
	private CoronaPatientMgmtService service;

	public MainController(CoronaPatientMgmtService service) {
		this.service = service;
	}
	public String processPatient(CoronaPatientVO vo) throws Exception{
		CoronaPatientDTO dto=null;
		String result=null;
		//convert CustomerVO to CustomerDTO
		dto=new CoronaPatientDTO();
		dto.setPname(vo.getPname());
		dto.setPadd(vo.getPadd());
		dto.setStage(vo.getStage());
		dto.setDays_at_hospital(Integer.parseInt(vo.getDays_at_hospital()));
		
		
		//use service
		result=service.calculateBillAmt(dto);
		return result;
	
	}
}

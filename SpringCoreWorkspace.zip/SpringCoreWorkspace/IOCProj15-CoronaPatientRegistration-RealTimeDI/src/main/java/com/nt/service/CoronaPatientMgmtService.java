package com.nt.service;

import com.nt.dto.CoronaPatientDTO;

public interface CoronaPatientMgmtService {
	public String calculateBillAmt(CoronaPatientDTO dto) throws Exception;

}

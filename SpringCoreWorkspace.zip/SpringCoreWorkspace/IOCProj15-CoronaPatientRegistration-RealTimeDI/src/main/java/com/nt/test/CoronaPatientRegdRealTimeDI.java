package com.nt.test;

import java.util.Scanner;

import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;

import com.nt.controller.MainController;
import com.nt.vo.CoronaPatientVO;

public class CoronaPatientRegdRealTimeDI {
	
	public static void main(String[] args) {
		Scanner sc=null;
		String pname=null,padd=null,days_at_hospital=null,stage=null;
		CoronaPatientVO vo=null;
		DefaultListableBeanFactory factory=null;
		XmlBeanDefinitionReader reader=null;
		MainController controller=null;
		String result=null;
		//read inputs
		sc=new Scanner(System.in);
		System.out.println("Enter Patient name :: ");
		pname=sc.next();
		System.out.println("Enter Patient Addrs::");
		padd=sc.next();
		System.out.println("Enter Patient stage of corona::");
		stage=sc.next();
		System.out.println("Enter Patient admitted how many days at hospital:");
		days_at_hospital=sc.next();

		// Store inputs in  VO class object
		vo=new CoronaPatientVO();
		vo.setPname(pname); vo.setPadd(padd); vo.setStage(stage); vo.setDays_at_hospital(days_at_hospital);
		//create BEanFacory IOC container
		factory=new DefaultListableBeanFactory();
		reader=new XmlBeanDefinitionReader(factory);
		reader.loadBeanDefinitions("com/nt/cfgs/applicationContext.xml");
		//get Controller Bean class object..
		 controller=factory.getBean("controller",MainController.class);
		 //invoke the method
		 try {
			 result=controller.processPatient(vo);
			 System.out.println(result);
		 }
		 catch(Exception e) {
			 System.out.println("Internal Problem");
			 e.printStackTrace();
		 }
	}

}

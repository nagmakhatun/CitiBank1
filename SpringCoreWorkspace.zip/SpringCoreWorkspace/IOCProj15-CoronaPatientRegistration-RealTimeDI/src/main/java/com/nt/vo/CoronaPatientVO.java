package com.nt.vo;

public class CoronaPatientVO {
	private String pname;
	private String padd;
	private String stage;
	private String days_at_hospital;
	private String billAmt;
	
	//setters and getters
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPadd() {
		return padd;
	}
	public void setPadd(String padd) {
		this.padd = padd;
	}
	public String getStage() {
		return stage;
	}
	public void setStage(String stage) {
		this.stage = stage;
	}
	public String getDays_at_hospital() {
		return days_at_hospital;
	}
	public void setDays_at_hospital(String days_at_hospital) {
		this.days_at_hospital = days_at_hospital;
	}
	public String getBillAmt() {
		return billAmt;
	}
	public void setBillAmt(String billAmt) {
		this.billAmt = billAmt;
	}
	
	

}

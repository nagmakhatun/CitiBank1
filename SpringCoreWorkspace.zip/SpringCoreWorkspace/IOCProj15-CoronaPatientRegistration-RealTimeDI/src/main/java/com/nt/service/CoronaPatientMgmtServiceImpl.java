package com.nt.service;

import com.nt.bo.CoronaPatientBO;
import com.nt.dao.CoronaPatientDAO;
import com.nt.dto.CoronaPatientDTO;

public final class CoronaPatientMgmtServiceImpl implements CoronaPatientMgmtService {
	private CoronaPatientDAO dao;
	
	public CoronaPatientMgmtServiceImpl(CoronaPatientDAO dao) {
		this.dao = dao;
	}

	@Override
	public String calculateBillAmt(CoronaPatientDTO dto) throws Exception {
		float billamt=0.0f;
		CoronaPatientBO bo=null;
		int count=0;
		//calculate billAmt
		billamt=dto.getDays_at_hospital()*3000;
		
		//prepare CustomerBO object having persistable data
		bo=new CoronaPatientBO();
		bo.setPname(dto.getPname());
		bo.setPadd(dto.getPadd());
		bo.setStage(dto.getStage());
		bo.setBillAmt(billamt);
		
		
		//use DAO
		count=dao.insert(bo);
		
		//process the result
		if(count==0)
			return "No Corona Patient Admitted At Hospital::Amt::"+dto.getBillAmt();
		else
			return " Corona Patient Admitted At Hospital::for DAys=   "+dto.getDays_at_hospital()+" .   BillAmt::"+billamt;
	
	}

}

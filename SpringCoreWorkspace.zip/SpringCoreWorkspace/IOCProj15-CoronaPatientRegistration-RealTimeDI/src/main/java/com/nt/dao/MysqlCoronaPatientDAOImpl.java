package com.nt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.sql.DataSource;

import com.nt.bo.CoronaPatientBO;

public class MysqlCoronaPatientDAOImpl implements CoronaPatientDAO {
	private static final String PATIENT_INSERT_QUERY="INSERT INTO SPRING_CORONA_REGD(PNAME,PADD,STAGE,BILLAMT) VALUES(?,?,?,?)";
	private DataSource ds;

	public MysqlCoronaPatientDAOImpl(DataSource ds) {
		this.ds = ds;
	}

	@Override
	public int insert(CoronaPatientBO bo) throws Exception {
		Connection con=null;
		PreparedStatement ps=null;
        int count=0;
	    
	    //create jdbc connection pool object 
		con=ds.getConnection();
		//create preparedStatement object
	     ps=con.prepareStatement(PATIENT_INSERT_QUERY);
	     
	     //set Query param value
	     ps.setString(1,bo.getPname());
	     ps.setString(2,bo.getPadd()); 
	     ps.setString(3, bo.getStage());
	     ps.setFloat(4,bo.getBillAmt());
	     
	     //update and execute sql query
	     count=ps.executeUpdate();
	    
	     //close preparedStatement object
	     ps.close();
	     
	     //close connection object
	     con.close();
		
		return count;
	}

}

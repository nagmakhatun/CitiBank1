package com.nt.dao;

import com.nt.bo.CoronaPatientBO;

public interface CoronaPatientDAO {
	public int insert(CoronaPatientBO bo) throws Exception;

}

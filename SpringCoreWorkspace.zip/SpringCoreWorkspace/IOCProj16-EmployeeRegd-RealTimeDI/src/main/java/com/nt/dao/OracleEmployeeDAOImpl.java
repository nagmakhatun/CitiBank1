package com.nt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.sql.DataSource;

import com.nt.bo.EmployeeBO;

public final class OracleEmployeeDAOImpl implements EmployeeDAO {
	private static final String  EMPLOYEE_INSERT_QUERY="INSERT INTO SPRING_EMPLOYEE VALUES(ENO_SEQ1.NEXTVAL,?,?,?,?)";
	private DataSource ds;
	
	public OracleEmployeeDAOImpl(DataSource ds) {
		this.ds = ds;
	}

@Override
	public int insert(EmployeeBO bo) throws Exception {
	 //jdbc code to insert record	
	    Connection con=null;
		PreparedStatement ps=null;
		int count=0;
	    
	    //create jdbc connection pool object 
		con=ds.getConnection();
		//create preparedStatement object
	     ps=con.prepareStatement( EMPLOYEE_INSERT_QUERY);
	     //set Query param value
	     ps.setString(1,bo.getEname());
	     ps.setString(2,bo.getEadd()); 
	     ps.setString(3, bo.getDesignation());
	     ps.setFloat(4,bo.getEbsal());
	     
	     //update and execute sql query
	     count=ps.executeUpdate();
	    
	     //close preparedStatement object
	     ps.close();
	     
	     //close connection object
	     con.close();
		
		return count;
	}

}

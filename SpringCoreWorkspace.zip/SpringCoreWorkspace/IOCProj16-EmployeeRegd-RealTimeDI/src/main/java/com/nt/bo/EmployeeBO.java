package com.nt.bo;

public class EmployeeBO {
	private String ename;
	private String eadd;
	private String designation;
	private float ebsal;
	private float ensal;
	private float egsal;
	
	//setters & getterssr
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getEadd() {
		return eadd;
	}
	public void setEadd(String eadd) {
		this.eadd = eadd;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public float getEbsal() {
		return ebsal;
	}
	public void setEbsal(float ebsal) {
		this.ebsal = ebsal;
	}
	public float getEnsal() {
		return ensal;
	}
	public void setEnsal(float ensal) {
		this.ensal = ensal;
	}
	public float getEgsal() {
		return egsal;
	}
	public void setEgsal(float egsal) {
		this.egsal = egsal;
	}
	
	
	

	
}

package com.nt.service;

import com.nt.dto.EmployeeDTO;

public interface EmployeeMgmtService {
	public String calculateGrossSal(EmployeeDTO dto) throws Exception;

}

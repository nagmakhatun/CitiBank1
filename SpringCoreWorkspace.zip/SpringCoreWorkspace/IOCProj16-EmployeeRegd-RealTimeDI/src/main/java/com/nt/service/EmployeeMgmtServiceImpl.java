package com.nt.service;

import com.nt.bo.EmployeeBO;
import com.nt.dao.EmployeeDAO;
import com.nt.dto.EmployeeDTO;

public final class EmployeeMgmtServiceImpl implements EmployeeMgmtService {
	private EmployeeDAO dao;

	public EmployeeMgmtServiceImpl(EmployeeDAO dao) {
		this.dao = dao;
	}

	@Override
	public String calculateGrossSal(EmployeeDTO dto) throws Exception {
		float netSal, grossSal = 0.0f;
		EmployeeBO bo = null;
		int count = 0;
		String designation=null; ;
		// calculate net and gross sal
		if (dto.getDesignation().equalsIgnoreCase("manager")) {
			grossSal = dto.getEbsal() + dto.getEbsal() * 0.6f;
			netSal = grossSal - (grossSal * 0.1f);
		}
		else if(dto.getDesignation().equalsIgnoreCase("developer")) {
			grossSal = dto.getEbsal() + dto.getEbsal() * 0.4f;
			netSal = grossSal - (grossSal * 0.2f);
		}
		else {
			grossSal = dto.getEbsal() + dto.getEbsal() * 0.3f;
			netSal = grossSal - (grossSal * 0.3f);
		}

		// prepare CustomerBO object having persistable data
		bo = new EmployeeBO();
		bo.setEname(dto.getEname());
		bo.setEadd(dto.getEadd());
		bo.setDesignation(dto.getDesignation());
		bo.setEnsal(netSal);
		bo.setEgsal(grossSal);

		// use DAO
		count = dao.insert(bo);

		// process the result
		if (count == 0)
			return "Employee Registration failed";
		else
			return "Employee Registration succeeded::Basic Salary::" + dto.getEbsal() + "   Net Salary::" + netSal
					+ "   Gross Salary::" + grossSal;

	}

}

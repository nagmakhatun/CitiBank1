package com.nt.vo;

public class EmployeeVO {
	private String ename;
	private String eadd;
	private String designation;
	private String ebsal;
	
	//setters & getters
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getEadd() {
		return eadd;
	}
	public void setEadd(String eadd) {
		this.eadd = eadd;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getEbsal() {
		return ebsal;
	}
	public void setEbsal(String ebsal) {
		this.ebsal = ebsal;
	}
	
	

}

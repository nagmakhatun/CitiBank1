package com.nt.beans;

import java.util.Date;
import java.util.Set;

public class ContactsInfo {
	private Set<Long> contactNumber;
	private Set<Date> dates;
	
	public ContactsInfo(Set<Long> contactNumber, Set<Date> dates) {
		System.out.println(contactNumber.getClass());
		this.contactNumber = contactNumber;
		this.dates = dates;
	}

	@Override
	public String toString() {
		return "ContactsInfo [contactNumber=" + contactNumber + ", dates=" + dates + "]";
	}
	
	
	
	
	

}

package com.nt.beans;

import java.util.Date;
import java.util.Map;
import java.util.Properties;

public class UniversityInfo {
	private Map<Integer,String> facultyInfo;
	private Map<String,Date> dates;
	private Properties fruitsName;
	
	//setters
	public void setFacultyInfo(Map<Integer, String> facultyInfo) {
		System.out.println(facultyInfo.getClass());
		this.facultyInfo = facultyInfo;
	}
	public void setDates(Map<String, Date> dates) {
		this.dates = dates;
	}
		
	public void setFruitsName(Properties fruitsName) {
		this.fruitsName = fruitsName;
	}
	@Override
	public String toString() {
		return "UniversityInfo [facultyInfo=" + facultyInfo + ", dates=" + dates + ", fruitsName=" + fruitsName + "]";
	}

	
	
	

}

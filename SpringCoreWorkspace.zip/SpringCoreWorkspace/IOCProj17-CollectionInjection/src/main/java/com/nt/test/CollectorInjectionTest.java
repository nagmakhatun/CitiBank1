package com.nt.test;

import org.springframework.beans.factory.support.BeanDefinitionReader;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;

import com.nt.beans.College;
import com.nt.beans.ContactsInfo;
import com.nt.beans.MarksInfo;
import com.nt.beans.UniversityInfo;

public class CollectorInjectionTest {

	public static void main(String[] args) {
		MarksInfo marks=null;
		College clg=null;
		ContactsInfo info=null;
		UniversityInfo uInfo=null;
		DefaultListableBeanFactory factory=null;
		BeanDefinitionReader reader=null;
		
		factory=new DefaultListableBeanFactory();
		reader=new XmlBeanDefinitionReader(factory);
		reader.loadBeanDefinitions("com/nt/cfgs/applicationContext.xml");
		
		marks=factory.getBean("mi", MarksInfo.class);
		
		System.out.println(marks);
		
		System.out.println("=========================================================");
		 clg=factory.getBean("clg", College.class);
		System.out.println(clg);
		
		System.out.println("=========================================================");
		 info=factory.getBean("cInfo", ContactsInfo.class);
		System.out.println(info);
		
		System.out.println("=========================================================");
		 uInfo=factory.getBean("uInfo", UniversityInfo.class);
		System.out.println(uInfo);

	}

}

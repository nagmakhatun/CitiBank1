package com.nt.beans;

import java.util.Date;
import java.util.List;

public class College {
	private List<Date> dates;
	private List<String> studentName;
	
	public void setStudentName(List<String> studentName) {
		this.studentName = studentName;
	}
	public void setDates(List<Date> dates) {
		this.dates = dates;
	}
	
	@Override
	public String toString() {
		return "College [studentName=" + studentName + ", dates=" + dates + "]";
	}
	

}

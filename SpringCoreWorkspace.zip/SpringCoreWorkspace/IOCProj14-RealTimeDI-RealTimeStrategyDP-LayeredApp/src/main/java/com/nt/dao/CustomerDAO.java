package com.nt.dao;

import com.nt.bo.CustomerBO;

public interface CustomerDAO {
	public int insert(CustomerBO bo) throws Exception;

}

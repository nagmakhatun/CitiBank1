package com.nt.service;

import com.nt.dto.CustomerDTO;

public interface CustomerMgmtService {
	public String calculateIntrstAmt(CustomerDTO dto) throws Exception;

}

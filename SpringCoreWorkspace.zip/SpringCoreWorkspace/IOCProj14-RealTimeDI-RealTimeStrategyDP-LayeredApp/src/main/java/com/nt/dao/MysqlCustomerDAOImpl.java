package com.nt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.sql.DataSource;

import com.nt.bo.CustomerBO;

public final class MysqlCustomerDAOImpl implements CustomerDAO {
	private static final String CUSTOMER_INSERT_QUERY="INSERT INTO SPRING_CUSTOMER(CNAME,CADD,PAMT,INTRSTAMT) VALUES(?,?,?,?)";
	private DataSource ds;
	
	public MysqlCustomerDAOImpl(DataSource ds) {
		this.ds = ds;
	}

@Override
	public int insert(CustomerBO bo) throws Exception {
	 //jdbc code to insert record	
	    Connection con=null;
		PreparedStatement ps=null;
		int count=0;
	    
	    //create jdbc connection pool object 
		con=ds.getConnection();
		//create preparedStatement object
	     ps=con.prepareStatement(CUSTOMER_INSERT_QUERY);
	     //set Query param value
	     ps.setString(1,bo.getCname());
	     ps.setString(2,bo.getCadd()); 
	     ps.setFloat(3, bo.getPamt());
	     ps.setFloat(4,bo.getIntrstamt());
	     
	     //update and execute sql query
	     count=ps.executeUpdate();
	    
	     //close preparedStatement object
	     ps.close();
	     
	     //close connection object
	     con.close();
		
		return count;
	}

}

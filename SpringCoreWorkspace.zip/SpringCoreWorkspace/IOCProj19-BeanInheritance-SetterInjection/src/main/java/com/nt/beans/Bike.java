package com.nt.beans;

public class Bike {
	private String regdNo;
	private String engineNo;
	private String model;
	private String company;
	private int engineCC;
	private String color;
	private String owner;
	private String fuelType;
	private String type;
	private String mileage;
	
	
	//setters method
	public void setRegdNo(String regdNo) {
		this.regdNo = regdNo;
	}
	public void setEngineNo(String engineNo) {
		this.engineNo = engineNo;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public void setEngineCC(int engineCC) {
		this.engineCC = engineCC;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public void setFuelType(String fuelType) {
		this.fuelType = fuelType;
	}
	public void setType(String type) {
		this.type = type;
	}
	public void setMileage(String mileage) {
		this.mileage = mileage;
	}
	
	
	@Override
	public String toString() {
		return "Bike [regdNo=" + regdNo + ", engineNo=" + engineNo + ", model=" + model + ", company=" + company
				+ ", engineCC=" + engineCC + ", color=" + color + ", owner=" + owner + ", fuelType=" + fuelType
				+ ", type=" + type + ", mileage=" + mileage + "]";
	}
	
}

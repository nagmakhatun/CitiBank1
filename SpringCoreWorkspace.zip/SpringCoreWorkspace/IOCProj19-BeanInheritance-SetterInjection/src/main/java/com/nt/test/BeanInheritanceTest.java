package com.nt.test;

import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;

import com.nt.beans.Bike;

public class BeanInheritanceTest {

	public static void main(String[] args) {
		DefaultListableBeanFactory factory=null;
		XmlBeanDefinitionReader reader=null;
		Bike nagma=null,saurabh=null,jishan=null,base=null;
		
		factory=new DefaultListableBeanFactory();
		reader=new XmlBeanDefinitionReader(factory);
		reader.loadBeanDefinitions("com/nt/cfgs/applicationContext.xml");
		
		nagma=factory.getBean("nagmaBike",Bike.class);
		System.out.println(nagma);
		System.out.println("..................................................................................");
		
		saurabh=factory.getBean("saurabhBike",Bike.class);
		System.out.println(saurabh);
		System.out.println("..................................................................................");
		
		jishan=factory.getBean("jishanBike",Bike.class);
		System.out.println(jishan);
        System.out.println("..................................................................................");
		
        //we will get Exception for this as its an abstract bean so cant instantiate
	//	base=factory.getBean("baseBike",Bike.class);
	//	System.out.println(base);
		

	}

}

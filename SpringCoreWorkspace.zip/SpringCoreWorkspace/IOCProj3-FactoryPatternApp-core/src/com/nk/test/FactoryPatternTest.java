package com.nk.test;

import com.nk.cmp.Car;
import com.nk.factory.CarFactory;

public class FactoryPatternTest {
	public static void main(String[] args) {
		Car car=null;
		car=CarFactory.getCar("luxury");
		car.drive();
		System.out.println("----------------------------------------------");
		car=CarFactory.getCar("budget");
		car.drive();
		System.out.println("----------------------------------------------");
		car=CarFactory.getCar("sports");
		car.drive();
		
	}

}

package com.nk.factory;

import com.nk.cmp.ApolloTyre;
import com.nk.cmp.BudgetCar;
import com.nk.cmp.CEATTyre;
import com.nk.cmp.Car;
import com.nk.cmp.LuxuryCar;
import com.nk.cmp.MRFTyre;
import com.nk.cmp.SportsCar;
import com.nk.cmp.Tyre;

public class CarFactory {
	
	
	public static Car getCar(String type) {
		Car car=null;
		Tyre tyre=null;
		if(type.equalsIgnoreCase("luxury")) {
			tyre=new CEATTyre();
			car=new LuxuryCar(tyre);
		}
		else if(type.equalsIgnoreCase("sports")) {
			tyre=new MRFTyre();
			car=new SportsCar(tyre);
		}
		else if(type.equalsIgnoreCase("budget")) {
			tyre=new ApolloTyre();
			car=new BudgetCar(tyre);
		}
			
		return car;
	}

}

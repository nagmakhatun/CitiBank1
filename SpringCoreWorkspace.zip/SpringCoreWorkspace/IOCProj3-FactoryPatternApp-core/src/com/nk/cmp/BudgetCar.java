package com.nk.cmp;

public class BudgetCar implements Car {
	private Tyre tyre;

	public BudgetCar(Tyre tyre) {
		this.tyre = tyre;
	}
	
	@Override
	public void drive() {
		System.out.println("Driving Budget Car with the comfort of "+tyre.roadGrip());;
	}
	
	

}

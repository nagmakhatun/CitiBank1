package com.nk.cmp;

public interface Car {
	public void drive();

}

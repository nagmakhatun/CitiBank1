package com.nk.cmp;

public class CEATTyre implements Tyre {
	public CEATTyre() {
		System.out.println("CEATTyre::0-param constructor");
	}
	
	@Override
	public String roadGrip() {
		return "CEATTyre::suitable for Luxury Car";
	
	}

}

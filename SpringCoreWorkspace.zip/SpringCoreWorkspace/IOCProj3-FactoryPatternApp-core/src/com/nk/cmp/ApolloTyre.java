package com.nk.cmp;

public class ApolloTyre implements Tyre {
	public ApolloTyre() {
		System.out.println("ApolloTyre::0-param constructor");
	}
	
	@Override
	public String roadGrip() {
		return "ApolloTyre::suitable for Budget Car";
	
	}

}

package com.nk.cmp;

public interface Tyre {
	public String roadGrip();

}

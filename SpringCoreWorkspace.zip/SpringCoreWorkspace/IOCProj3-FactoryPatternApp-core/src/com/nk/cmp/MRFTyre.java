package com.nk.cmp;

public class MRFTyre implements Tyre {
	public MRFTyre() {
		System.out.println("MRFTyre::0-param constructor");
	}
	
	@Override
	public String roadGrip() {
		return "MRFTyre::suitable for sports Car";
		

	}

}

package com.nt.beans;

import java.util.Date;

public class PersonInfo {
	private long ano;
	private String name;
	private String add;
	private Date dob;
	private Date dom;
	private Date doj;
	
	public PersonInfo(long ano, String name, String add, Date dob, Date dom, Date doj) {
		System.out.println("PersonInfo::6-param Constructor");
		this.ano = ano;
		this.name = name;
		this.add = add;
		this.dob = dob;
		this.dom = dom;
		this.doj = doj;
	}

	@Override
	public String toString() {
		return "PersonInfo [ano=" + ano + ", name=" + name + ", add=" + add + ", dob=" + dob + ", dom=" + dom + ", doj="
				+ doj + "]";
	}
	
	
	
	

}

package com.nt.test;

import org.springframework.beans.factory.support.BeanDefinitionReader;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;

import com.nt.beans.PersonInfo;

public class NullInjectionTest {

	public static void main(String[] args) {
		DefaultListableBeanFactory factory=null;
		BeanDefinitionReader reader=null;
		
		PersonInfo nagma=null,saurabh=null;
		
		factory=new DefaultListableBeanFactory();
		reader=new XmlBeanDefinitionReader(factory);
		reader.loadBeanDefinitions("com/nt/cfgs/applicationContext.xml");
		
		nagma=factory.getBean("nagmaInfo", PersonInfo.class);
		System.out.println(nagma);
		System.out.println("-------------------------------------------------------------------------------------------");
		
		saurabh=factory.getBean("saurabhInfo", PersonInfo.class);
		System.out.println(saurabh);
		

	}

}

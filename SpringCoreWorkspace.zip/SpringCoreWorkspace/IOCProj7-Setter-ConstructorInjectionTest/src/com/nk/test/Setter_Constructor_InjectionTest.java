package com.nk.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.nk.comp.Student;

public class Setter_Constructor_InjectionTest {
	public static void main(String[] args) {
		BeanFactory factory=null;
		Student stud=null;
		
		//create bean class object
		factory=new XmlBeanFactory(new ClassPathResource("com/nk/cnfgs/applicationContext.xml"));
		
		//get bean factory
		stud=factory.getBean("stud", Student.class);
		
		System.out.println(stud);
		
	}

}

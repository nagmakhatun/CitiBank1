package com.nk.test;

import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;

import com.nk.comp.A;
import com.nk.comp.B;


public class CyclicDI_Test_UsingConstructorAndSetter{
	public static void main(String[] args) {
		System.out.println("CyclicDI_Test_UsingConstructorAndSetter.main()");
		//BeanFactory factory=null;
		DefaultListableBeanFactory factory=null;
		XmlBeanDefinitionReader reader=null;
		
		A a1=null;
		B b1=null;
		
		//create bean class object
		
		//factory=new XmlBeanFactory(new ClassPathResource("com/nk/cnfgs/applicationContext.xml"));
		
		//create bean class object using DefaultListableBeanFactory & XmlBeanDefinitionReader
		                                                   // as XmlBeanFactory is deprecated
		
		factory=new DefaultListableBeanFactory();
		reader=new XmlBeanDefinitionReader(factory);
		reader.loadBeanDefinitions("com/nk/cnfgs/applicationContext.xml");
		
		
		//get bean class object
		a1=factory.getBean("a1",A.class);
		System.out.println(a1);
		System.out.println("......................................");
		
		  b1=factory.getBean("b1",B.class);
		   System.out.println(b1);
		 
	}

}

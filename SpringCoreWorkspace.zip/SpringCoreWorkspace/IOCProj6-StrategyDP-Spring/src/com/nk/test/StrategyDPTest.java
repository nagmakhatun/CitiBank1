package com.nk.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.nk.comp.Flipkart2;

public class StrategyDPTest {

	public static void main(String[] args) {
		Resource res=null;
		BeanFactory factory=null;
		Flipkart2 fpkt=null;
		
		//get Resource object with configuration file location
		res=new ClassPathResource("com/nk/cnfgs/applicationContext.xml");
		
		//create bean factory object with resorce object as parameter
		factory=new XmlBeanFactory(res);
		
		//get bean class object
		fpkt=factory.getBean("fpkt", Flipkart2.class);
		
		//invoke factory class b.logic method
		System.out.println(fpkt.shopping(new String[] {"Dress","makeup Accesories","Bangles","superman chaddi"}, 
                new float[] {5000,8000,500,800}
                ));

	}

}

package com.nk.comp;

import java.util.Arrays;

//Rule#3
public final class Flipkart2 {
	private Courier courier1,courier2;
	
	public Flipkart2() {
		System.out.println("Flipkart::0-param constructor");
	}
	

	
	/*
	 * public Flipkart(Courier courier) {
	 * System.out.println("Flipkart::1-param constructor"); this.courier = courier;
	 * }
	 */
	
	public Flipkart2(Courier courier1, Courier courier2) {
		System.out.println("Flipkart::2-param constructor");
		this.courier1 = courier1;
		this.courier2 = courier2;
	}

	/*
	 * public void setCourier(Courier courier) {
	 * System.out.println("Flipkart.setCourier()"); this.courier = courier; }
	 */

	public String shopping( String[] items,float[] price) {
		System.out.println("Flipkart.shopping()");
		float billAmt=0.0f;
		int oid=0;
		String msg1,msg2=null;
		//calculate bill Amount
		for(float p:price)
			//billAmt=billAmt+p;
			billAmt+=p;
		//generate order id dynamically
		oid=new java.util.Random().nextInt(1000);
		
		//send Status
		msg1=courier1.deliver(oid);
		msg2=courier2.deliver(oid);
		
		return Arrays.toString(items) +" are purchased having prices "+Arrays.toString(price)
		                             +"with bill Amount: "+billAmt+"-------"+msg1+"....."+msg2;
		
	}
	
	

}

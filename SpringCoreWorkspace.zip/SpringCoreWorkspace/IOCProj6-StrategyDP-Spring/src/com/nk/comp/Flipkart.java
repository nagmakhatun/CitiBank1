package com.nk.comp;

import java.util.Arrays;

//Rule#3
public final class Flipkart {
	private Courier courier;
	
	public Flipkart() {
		System.out.println("Flipkart::0-param constructor");
	}
	

	
	
	  public Flipkart(Courier courier) {
		  System.out.println("Flipkart::1-param constructor");
		  this.courier = courier;
	  }
	 

	
	  public void setCourier(Courier courier) {
		  System.out.println("Flipkart.setCourier()"); 
		  this.courier = courier;
	  }
	 

	public String shopping( String[] items,float[] price) {
		System.out.println("Flipkart.shopping()");
		float billAmt=0.0f;
		int oid=0;
		String msg=null;
		//calculate bill Amount
		for(float p:price)
			//billAmt=billAmt+p;
			billAmt+=p;
		//generate order id dynamically
		oid=new java.util.Random().nextInt(1000);
		
		//send Status
		msg=courier.deliver(oid);
		
		return Arrays.toString(items) +" are purchased having prices "+Arrays.toString(price)
		                             +"with bill Amount: "+billAmt+"-------"+msg;
		
	}
	
	

}

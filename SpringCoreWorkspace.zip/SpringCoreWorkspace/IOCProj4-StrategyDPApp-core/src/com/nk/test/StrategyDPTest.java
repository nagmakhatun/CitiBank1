package com.nk.test;

import com.nk.comp.Flipkart;
import com.nk.factory.FlipkartFactory;

public class StrategyDPTest {
	
	public static void main(String[] args) {
		Flipkart fkrt=null;
		fkrt=FlipkartFactory.getInstance("dtdc");
		System.out.println(fkrt.shopping(new String[] {"Dress","makeup Accesories","Bangles","superman chaddi"}, 
				                                                            new float[] {5000,8000,500,800}
		                                                                  )
				                              );
	}

}

package com.nk.factory;

import com.nk.comp.BlueDartCourier;
import com.nk.comp.Courier;
import com.nk.comp.DTDCCourier;
import com.nk.comp.FirstFlightCourier;
import com.nk.comp.Flipkart;

public class FlipkartFactory {
	
	public static Flipkart getInstance(String courierService) {
		Flipkart fkrt=null;
		Courier courier=null;
		
		if(courierService.equalsIgnoreCase("dtdc"))
			courier=new DTDCCourier();
		else if(courierService.equalsIgnoreCase("blueDart"))
			courier=new BlueDartCourier();
		else if(courierService.equalsIgnoreCase("firstFlight"))
			courier=new FirstFlightCourier();
		else
			throw new IllegalArgumentException("No such Courier Service is available");
		//create target class object
		fkrt=new Flipkart();
		
		//assign dependent class to target class
		fkrt.setCourier(courier);
		
		return fkrt;
	}

}

package com.nk.comp;

public final class DTDCCourier implements Courier {
	public DTDCCourier() {
		System.out.println("DTDCCourier::0-param constructor");
	}

	@Override
	public String deliver(int orderid) {
		
		return "DTDC::Ur flipkart order having orderid"+orderid+" has been delivered successfully by our courier service";
	}

}

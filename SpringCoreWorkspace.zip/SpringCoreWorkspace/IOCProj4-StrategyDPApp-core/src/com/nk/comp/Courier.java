package com.nk.comp;

public interface Courier {
	public String deliver(int orderid);

}

package com.nk.comp;

public final class FirstFlightCourier implements Courier {
	
	public FirstFlightCourier() {
		System.out.println("FirstFlightCourier::0-param constructor");
	}

	@Override
	public String deliver(int orderid) {
		
		return "FirstFlight::Ur flipkart order having orderid"+orderid+" has been delivered successfully by our courier service";
	}

}

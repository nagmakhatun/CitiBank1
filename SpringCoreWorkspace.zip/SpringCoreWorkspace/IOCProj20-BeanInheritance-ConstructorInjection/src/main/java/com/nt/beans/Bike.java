package com.nt.beans;

public class Bike {
	private String regdNo;
	private String engineNo;
	private String model;
	private String company;
	private int engineCC;
	private String color;
	private String owner;
	private String fuelType;
	private String type;
	private String mileage;
	
	

	
	public Bike(String regdNo, String engineNo, String model, String company, int engineCC, String color, String owner,
			String fuelType, String type, String mileage) {
		System.out.println("Bike::10-param Constructor");
		this.regdNo = regdNo;
		this.engineNo = engineNo;
		this.model = model;
		this.company = company;
		this.engineCC = engineCC;
		this.color = color;
		this.owner = owner;
		this.fuelType = fuelType;
		this.type = type;
		this.mileage = mileage;
	}




	@Override
	public String toString() {
		return "Bike [regdNo=" + regdNo + ", engineNo=" + engineNo + ", model=" + model + ", company=" + company
				+ ", engineCC=" + engineCC + ", color=" + color + ", owner=" + owner + ", fuelType=" + fuelType
				+ ", type=" + type + ", mileage=" + mileage + "]";
	}
	
}

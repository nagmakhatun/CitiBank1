package com.nk.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.nk.comp.Employee;

public class ConstructorInjectionOrderTest {
	public static void main(String[] args) {
		System.out.println("ConstructorInjectionOrderTest.main()");
		BeanFactory factory=null;
		Employee emp=null;
		
		//create bean class object
		factory=new XmlBeanFactory(new ClassPathResource("com/nk/cnfgs/applicationContext.xml"));
		//get bean class object
		emp=factory.getBean("emp",Employee.class);
		System.out.println(emp);
	}

}

package com.nk.comp;

public class Employee {
	private  int eno;
	private String ename;
	private String eadd;
	private float esal;
	
	
	public Employee(int eno, String ename, String eadd, float esal) {
		System.out.println("Employee::4-param constructor");
		this.eno = eno;
		this.ename = ename;
		this.eadd = eadd;
		this.esal = esal;
	}

	@Override
	public String toString() {
		return "Employee [eno=" + eno + ", ename=" + ename + ", eadd=" + eadd + ", esal=" + esal + "]";
	}
	
	

}

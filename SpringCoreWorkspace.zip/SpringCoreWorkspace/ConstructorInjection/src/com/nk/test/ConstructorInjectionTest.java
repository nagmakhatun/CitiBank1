package com.nk.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanDefinitionStoreException;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

import com.nk.beans.WishMessageGenerator;

public class ConstructorInjectionTest {
	public static void main(String[] args) {
		System.out.println("ConstructorInjectionTest.main()");
		
		Resource res=null;
		BeanFactory bean=null;
		Object obj=null;
		WishMessageGenerator generator=null;
		
		//hold name and location of spring bean config file in resource object
		//res=new FileSystemResource("src/com/nk/cnfgs/applicationContext.xml");  //using FileSystemResource
		//res=new ClassPathResource("com/nk/cnfgs/applicationContext.xml");  //Using ClassPathResource ..relative path
		res=new ClassPathResource("applicationContext.xml");   //Using ClassPathResource ..absolute path
		
		//create spring container(IOC container) BeanFactory
		bean=new XmlBeanFactory(res);
		
		//get target class object from bean Factory
		//obj=bean.getBean("wmg");
		
		//type cast target class objects object to target class only
		
		//generator=(WishMessageGenerator) obj;
		
		//we no need to typecast if we will use -->getBean(String BeanId,Class<T> required type)
		generator=bean.getBean("wmg", WishMessageGenerator.class);
		
		String result=generator.generateWishMessage("Nagma");
		
		System.out.println(result);
		
		
		
	}

}

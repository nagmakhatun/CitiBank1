package com.nk.comp;

public class Test1 {
	int a,b;
	
	public Test1() {
		System.out.println("Test1::0-param Constructor");
	}

	public Test1(int a, int b) {
		System.out.println("Test1::2-param Constructor");
		this.a = a;
		this.b = b;
	}

	@Override
	public String toString() {
		return "Test1 [a=" + a + ", b=" + b + "]";
	}

	
	
	
	
	
	
	
	
	
	
	

}

package com.nk.comp;

public class Test2 {
	int a,b,c;
	
	public Test2() {
		System.out.println("Test1::0-param Constructor");
	}
	
	
	
	public Test2(int a) {
		this.a = a;
	}

	public Test2(int a, int b) {
		System.out.println("Test1::2-param Constructor");
		this.a = a;
		this.b = b;
	}


	public Test2(int a, int b, int c) {
		this.a = a;
		this.b = b;
		this.c = c;
	}


	
	@Override
	public String toString() {
		return "Test2 [a=" + a + ", b=" + b + ", c=" + c + "]";
	}

	
	
	
	
	
	
	
	
	
	
	

}

package com.nk.test;

import java.lang.reflect.Constructor;

import com.nk.comp.Test1;

public class NewInstanceTest1 {
	
	public static void main(String[] args) {
		Class c=null;
		Constructor cns[];
		Object obj=null;
		try {
			//load the class
			 c=Class.forName(args[0]);
			 //get access to all constructors of the loaded class
			 cns=c.getDeclaredConstructors();
			 //instantiate the class using 2-param constructor
			obj=cns[1].newInstance(10,20);
			//type cast to given class
			Test1 t1=(Test1)obj;
			System.out.println(t1);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

package com.nk.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanDefinitionStoreException;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

import com.nk.beans.WishMessageGenerator;

public class SetterInjectionTest {
	public static void main(String[] args) {
		System.out.println("SetterInjectionTest.main()");
		
		Resource res=null;
		BeanFactory bean=null;
		Object obj=null;
		WishMessageGenerator generator=null;
		
		//hold name and location of spring bean config file in resource object
		res=new FileSystemResource("src/com/nk/cnfgs/applicationContext.xml");
		
		//create spring container(IOC container) BeanFactory
		bean=new XmlBeanFactory(res);
		
		//get target class object from bean Factory
		obj=bean.getBean("wmg");
		
		//type cast target class objects object to target class only
		
		generator=(WishMessageGenerator) obj;
		
		String result=generator.generateWishMessage("Nagma");
		
		System.out.println(result);
		
		
		
	}

}

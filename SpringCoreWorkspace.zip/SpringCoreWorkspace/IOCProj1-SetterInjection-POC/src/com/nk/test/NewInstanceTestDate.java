package com.nk.test;

import java.lang.reflect.Constructor;

import com.nk.comp.Test1;

public class NewInstanceTestDate {
	
	public static void main(String[] args) {
		Class c=null;
		Constructor cns[];
		Object obj=null;
		try {
			//load the class
			 c=Class.forName("java.util.Date");
			 //instantiate the class using  constructor
			obj=c.newInstance();
			//type cast to given class
			System.out.println("Date and time:: "+obj);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

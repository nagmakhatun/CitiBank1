package com.nk.test;

import java.lang.reflect.Constructor;

import com.nk.comp.Test2;

public class NewInstanceTest2 {
	
	public static void main(String[] args) {
		Class c=null;
		Constructor cns[];
		Object obj=null;
		try {
			//load the class
			 c=Class.forName(args[0]);
			 //get access to all constructors of the loaded class
			 cns=c.getDeclaredConstructors();
			 //instantiate the class using 3-param constructor
			obj=cns[0].newInstance(10,20,30);
			//type cast to given class
			Test2 t2=(Test2)obj;
			System.out.println(t2);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

package com.nk.test;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.nk.beans.Product;
import com.nt.utility.HibernateUtil;

public class SaveObjecttest {

	public static void main(String[] args) {
		//Configuration cfg=null;
		//SessionFactory factory=null;
		Session ses=null;
		Product prod=null;
		Transaction tx=null;
		boolean flag = false;
		
		//Activate Hibernate f/w 
		//cfg=new Configuration();
		
		//supply hibernate configuration file as input file
		//cfg.configure("com/nk/cfgs/hibernate.cfg.xml");
		
		 //create session factory
		//factory=cfg.buildSessionFactory();
		
		//System.out.println("Session Factory class name::"+factory.getClass());
		//open session factory to get session object
		ses=HibernateUtil.getSession();
		//ses=factory.openSession();
		System.out.println("Session object class name::"+ses.getClass());
		
		//create entity object to save in DB s/w
		prod=new Product();
		prod.setPid(841);
		prod.setPname("gas");
		prod.setPrice(5000);
		prod.setQty(5);
		
		try {
			tx=ses.beginTransaction();  //internally calls con.setautoCommit(false) to begin the transaction
			System.out.println("tx object class name::"+tx.getClass());
			//save session object
			//ses.save(prod);
			int idval=(int) ses.save(prod);
			System.out.println("1");
			System.out.println("generated idval::"+idval);
			flag = true;
		}
		catch (HibernateException he) {
			he.printStackTrace();
			flag=false;
		}
		
		finally {
			if(flag==true) {
				System.out.println("2");
				tx.commit();  //internally calls con.commit()
				System.out.println("3");
			    System.out.println("object is saved");
			}
			else {
				tx.rollback();   //internally calls con.rollback()
			    System.out.println("object is not saved");
			} 
			//close session object
			HibernateUtil.closeSession(ses);
			
			//close session factory
			HibernateUtil.closeFactory();
		}

	}

}

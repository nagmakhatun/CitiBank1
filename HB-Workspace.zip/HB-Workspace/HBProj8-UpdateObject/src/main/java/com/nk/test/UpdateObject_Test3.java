package com.nk.test;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nk.beans.BankAccount;
import com.nt.utility.HibernateUtil;

public class UpdateObject_Test3 {

	public static void main(String[] args) {
	
		Session ses=null;
		BankAccount account=null;
		Transaction tx=null;
		boolean flag=true;
		
		//open session factory to get session object
		ses=HibernateUtil.getSession();
		
		
		//create entity object to save in DB s/w
		account=new BankAccount();
		
		try {
			//load object
			account=ses.get(BankAccount.class, 1007);
			if (account != null) {
				tx = ses.beginTransaction();
				account.setHolderName("sara");
				flag = true;
			} else {
				System.out.println("account not found");
				return;
			}
			
		}
		catch (HibernateException he) {
			he.printStackTrace();
			flag=false;
			
		}
		
		finally {
			if(flag) {
			    tx.commit();
			    System.out.println("object is updated");
			}
			else {
				tx.rollback();
				System.out.println("object not updated");
			}
			//close session object
			HibernateUtil.closeSession(ses);
			
			//close session factory
			HibernateUtil.closeFactory();
		}

	}

}

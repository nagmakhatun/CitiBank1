package com.nk.beans;

import java.io.Serializable;

public class Membership implements Serializable{
	private long mid;
	private String name;
	private String addrs;
	private long rewardPoint;
	
	public Membership() {
		System.out.println("Membership::0-param constructor");
	}
	
	public long getMid() {
		return mid;
	}
	public void setMid(long mid) {
		this.mid = mid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddrs() {
		return addrs;
	}
	public void setAddrs(String addrs) {
		this.addrs = addrs;
	}
	public long getRewardPoint() {
		return rewardPoint;
	}
	public void setRewardPoint(long rewardPoint) {
		this.rewardPoint = rewardPoint;
	}
	
	//toString
	@Override
	public String toString() {
		return "Membership [mid=" + mid + ", name=" + name + ", addrs=" + addrs + ", rewardPoint=" + rewardPoint + "]";
	}
	
	
	

}

package com.nk.test;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nk.beans.Membership;
import com.nt.utility.HibernateUtil;

public class MergeObject_Test2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	
		Session ses=null;
		Membership member=null,member1=null,member2=null;
		Transaction tx=null;
		boolean flag=true;
		
		//open session factory to get session object
		ses=HibernateUtil.getSession();
		
		
		//load object
		member=ses.get(Membership.class,1L );
		System.out.println(member);
		
		try {
			tx=ses.beginTransaction();
			member1=new Membership();
			member1.setMid(1L);
			member1.setName("saurabh");
			member1.setAddrs("banda");
			member1.setRewardPoint(45L);
			
			//ses.save(member1);//throws NonUniqueObjectException
			//ses.persist(member1); //throws EntityExistsException
			//ses.update(member1);//throws NonUniqueObjectException
			//ses.delete(member1);//throws EntityExistsException
			//ses.saveOrUpdate(member1);//throws NonUniqueObjectException
			member2=(Membership) ses.merge(member1);
			System.out.println(member1 );
			System.out.println(member2);
			System.out.println(member.hashCode()+"....."+member1.hashCode()+"......"+member2.hashCode());
			flag=true;
	
			
		}
		catch (HibernateException he) {
			he.printStackTrace();
			flag=false;
			
		}
		
		finally {
			if(flag) {
			    tx.commit();
			    System.out.println("object is Saved and Updated");
			}
			else {
				tx.rollback();
				System.out.println("object not saved and updated");
			}
			//close session object
			HibernateUtil.closeSession(ses);
			
			//close session factory
			HibernateUtil.closeFactory();
		}

	
		
		

	}

}

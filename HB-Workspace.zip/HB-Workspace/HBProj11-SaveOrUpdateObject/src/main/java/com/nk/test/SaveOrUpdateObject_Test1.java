package com.nk.test;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nk.beans.Membership;
import com.nt.utility.HibernateUtil;

public class SaveOrUpdateObject_Test1 {

	public static void main(String[] args) {
	
		Session ses=null;
		Membership member=null;
		Transaction tx=null;
		boolean flag=true;
		
		//open session factory to get session object
		ses=HibernateUtil.getSession();
		
		
		//create entity object to save in DB s/w
		member=new Membership();
		member.setMid(66666666L);  //if mid and Unsaved-value will be same--->insert or update based on generator will happen
		                           //if mid and unsaved-value will not be same---->update takin mid take place
		member.setName("Nigar");  member.setAddrs("Jsg"); member.setRewardPoint(50L);
		
		try {
			tx=ses.beginTransaction();
			ses.saveOrUpdate(member);
			flag=true;
	
			
		}
		catch (HibernateException he) {
			he.printStackTrace();
			flag=false;
			
		}
		
		finally {
			if(flag) {
			    tx.commit();
			    System.out.println("object is Saved and Updated");
			}
			else {
				tx.rollback();
				System.out.println("object not saved and updated");
			}
			//close session object
			HibernateUtil.closeSession(ses);
			
			//close session factory
			HibernateUtil.closeFactory();
		}

	}

}

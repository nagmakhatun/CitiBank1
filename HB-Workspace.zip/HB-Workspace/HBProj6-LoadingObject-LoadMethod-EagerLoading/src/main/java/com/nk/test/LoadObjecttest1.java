package com.nk.test;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.nk.beans.IInsurancePolicy;
import com.nt.utility.HibernateUtil;

public class LoadObjecttest1 {

	public static void main(String[] args) {
	
		Session ses=null;
		IInsurancePolicy policy=null;
		
		
		//open session factory to get session object
		ses=HibernateUtil.getSession();
		//ses=factory.openSession();
		System.out.println("Session object class name::"+ses.getClass());
		
		//create entity object to save in DB s/w
		//policy=new InsurancePolicy();
		
		try {
			policy=ses.load(IInsurancePolicy.class, 70001L);
			System.out.println(policy.getClass()+"   "+policy.getClass().getSuperclass()+"    "+policy.getClass().getInterfaces());
			
			/*if(policy==null)
				System.out.println("Record not found");
			else
				System.out.println("Record Found");*/
			
			System.out.println(policy);
			
		}
		catch (HibernateException he) {
			he.printStackTrace();
			
		}
		catch (Exception e) {
			e.printStackTrace();
			
		}
		
		finally {
			
			//close session object
			HibernateUtil.closeSession(ses);
			
			//close session factory
			HibernateUtil.closeFactory();
		}

	}

}

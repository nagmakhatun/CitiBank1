package com.nt.test;

import java.util.Arrays;
import java.util.Scanner;

import com.nt.comp.EcommerceStore;
import com.nt.factory.EcommerceStoreFactory;

public class Customer1 {

	public static void main(String[] args) {
		Scanner scn=null;
		EcommerceStore store=null;
		/*store=EcommerceStoreFactory.getInstance("AMZN10");
		System.out.println(store.getClass());
		System.out.println("BillAmt:"+store.shopping(new String[]{"bag","earphone"},new double[] {5000,1800} ));*/
		
		scn=new Scanner(System.in);
		System.out.println("Enter CouponCode::");
		String coupon=scn.nextLine();
		store=EcommerceStoreFactory.getInstance(coupon);
		System.out.println(store.getClass());
		
		System.out.println("Enter Items with space::");
		String[] items=new String[] {scn.nextLine()};
		
		System.out.println("Enter price with comma(,)::");
		double[] price=new double[] {scn.nextDouble()};
		
		System.out.println("items are::"+Arrays.toString(items)+"   prices are:: "+Arrays.toString(price)+"   BillAmt:"+store.shopping(items,price ));
		
		

	}

}

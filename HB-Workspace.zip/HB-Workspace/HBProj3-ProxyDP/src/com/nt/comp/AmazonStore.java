package com.nt.comp;

import java.util.stream.DoubleStream;

public class AmazonStore implements EcommerceStore {

	/*@Override
	public double shopping(String[] items, double[] prices) {
		double total=0.0f;
		//calculate total
		for(double p:prices)
			total+=total;
		
		return total;
	}*/
	
	@Override
	public double shopping(String[] items, double[] prices) {
		double billAmt=0.0;
		billAmt=DoubleStream.of(prices).sum();
		
		return billAmt;
		
	}

}

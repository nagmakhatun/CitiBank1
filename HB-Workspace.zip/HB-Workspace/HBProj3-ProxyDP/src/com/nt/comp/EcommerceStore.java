package com.nt.comp;

public interface EcommerceStore {
	public double shopping(String[] items,double[] prices);
	

}

package com.nt.proxy;

import com.nt.comp.AmazonStore;
import com.nt.comp.EcommerceStore;

public class EcommerceStoreDiscountProxy implements EcommerceStore {
	private EcommerceStore real;
	private float discount;
	
	public EcommerceStoreDiscountProxy(float discount) {
		real = new AmazonStore();
		this.discount=discount;
	}

	@Override
	public double shopping(String[] items, double[] prices) {
		double billAmt=0.0;
		double finalAmt=0.0;
		
		billAmt=real.shopping(items, prices);
		finalAmt=billAmt-(billAmt*discount/100);
		
		return finalAmt;
	}

}

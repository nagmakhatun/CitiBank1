package com.nt.factory;

import com.nt.comp.AmazonStore;
import com.nt.comp.EcommerceStore;
import com.nt.proxy.EcommerceStoreDiscountProxy;

public class EcommerceStoreFactory {
	public static EcommerceStore getInstance(String couponcode) {
		if(couponcode.equalsIgnoreCase("")||couponcode.trim().length()==0)
			return new AmazonStore();
		else {
			if(couponcode.equalsIgnoreCase("AMZN10"))
				return new EcommerceStoreDiscountProxy(10);
			else if(couponcode.equalsIgnoreCase("AMZN30"))
				return new EcommerceStoreDiscountProxy(30);
			else if(couponcode.equalsIgnoreCase("AMZN50"))
				return new EcommerceStoreDiscountProxy(50);
			else
				return new EcommerceStoreDiscountProxy(5);
		}
		
	}

}

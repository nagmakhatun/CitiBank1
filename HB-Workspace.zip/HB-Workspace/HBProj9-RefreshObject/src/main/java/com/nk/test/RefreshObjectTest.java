package com.nk.test;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nk.beans.BankAccount;
import com.nt.utility.HibernateUtil;

public class RefreshObjectTest {

	public static void main(String[] args) {
	
		Session ses=null;
		BankAccount account=null;
		
		//open session factory to get session object
		ses=HibernateUtil.getSession();
		
		
		//create entity object to save in DB s/w
		account=new BankAccount();
		
		try {
			//load object
			account=ses.get(BankAccount.class, 1003);
			
			if (account != null) {
				System.out.println(account);
				System.out.println("modify 1001 data in Sql data base record");
				try {
					Thread.sleep(30000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				ses.refresh(account);
				System.out.println(account);
				
			} else {
				System.out.println("account not found");
				return;
			}
			
		}
		catch (HibernateException he) {
			he.printStackTrace();
			
			
		}
		
		finally {
			//close session object
			HibernateUtil.closeSession(ses);
			
			//close session factory
			HibernateUtil.closeFactory();
		}

	}

}

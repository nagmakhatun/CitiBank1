package com.nt.utility;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {
	private static SessionFactory factory;

	static {
		Configuration config = null;
		try {
			// bootstrap hibernate
			config = new Configuration();
			// input hibernate configuration file
			config.configure("com/nk/cfgs/hibernate.cfg.xml");
			// create SessionFactory object
			factory = config.buildSessionFactory();
		} catch (HibernateException he) {
			he.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static Session getSession() {
		if (factory != null)
			return factory.openSession();
		else
			return null;

	}

	public static void closeSession(Session ses) {
		if (ses != null)
			ses.close();
	}

	public static void closeFactory() {
		if (factory != null)
			factory.close();
	}

}

package com.nk.test;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nk.beans.BankAccount;
import com.nt.utility.HibernateUtil;

public class DeleteObjectTest {

	public static void main(String[] args) {

		Session ses = null;
		BankAccount account = null;
		Transaction tx = null;
		boolean flag = true;

		// open session factory to get session object
		ses = HibernateUtil.getSession();

		

		try {
				tx = ses.beginTransaction();
				// create entity object to save in DB s/w
				account = new BankAccount();
				account.setAccNo(1001);
				flag = true;
				
		} catch (HibernateException he) {
			he.printStackTrace();
			flag = false;

		}

		finally {
			if (flag) {
				tx.commit();
				System.out.println("object is deleted");
			} else {
				tx.rollback();
				System.out.println("object not deleted");
			}
			// close session object
			HibernateUtil.closeSession(ses);

			// close session factory
			HibernateUtil.closeFactory();
		}

	}

}

package com.santosh.hospital.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.beanutils.BeanUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.santosh.hospital.config.HandlerConfig;
import com.santosh.hospital.config.SiteConfig;
import com.santosh.hospital.config.ViewConfig;

public final class SiteFrontServlet extends HttpServlet {

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occure
	 */
	public void init() throws ServletException {
		try{
			DocumentBuilderFactory dbf=DocumentBuilderFactory.newInstance();
			DocumentBuilder db=dbf.newDocumentBuilder();
			
			Document d=db.parse(getServletContext().getRealPath(getInitParameter("configFile")));
			Element site_config=d.getDocumentElement();
			Element handlers=(Element)(site_config.getElementsByTagName("handlers").item(0));
			NodeList handler_list=handlers.getElementsByTagName("handler");
			
			SiteConfig sc=new SiteConfig();
			
			Element def=(Element)site_config.getElementsByTagName("defaults").item(0);
			Element def_tmp=(Element)def.getElementsByTagName("default-template").item(0);
			
			sc.defaultTemplate=def_tmp.getFirstChild().getNodeValue();
			sc.defaultView=new ViewConfig();
			
			Element dvp=(Element)def.getElementsByTagName("default-view-parts").item(0);
			sc.defaultView.parts=new HashMap<String, String>();
			NodeList d_part_list=dvp.getElementsByTagName("part");
			for (int k=0; k<d_part_list.getLength(); k++){
				Element part=(Element)d_part_list.item(k);
				sc.defaultView.parts.put(part.getAttribute("name"),part.getAttribute("value"));	
			}
						
			sc.handlers=new HashMap<String, HandlerConfig>();
			for (int i=0; i<handler_list.getLength();i++){
				Element handler=(Element)handler_list.item(i);
				HandlerConfig hc=new HandlerConfig();
				sc.handlers.put(handler.getAttribute("path"),hc);
				
				hc.path=handler.getAttribute("path");
				hc.page=handler.getAttribute("page");
				hc.handlerClass=handler.getAttribute("class");
				hc.commandClass=handler.getAttribute("commandClass");
				hc.setCommandName(handler.getAttribute("commandName"));
				hc.setScope(handler.getAttribute("scope"));
				NodeList vnr_list=handler.getElementsByTagName("view-navigation-rules");
				if (vnr_list.getLength()==0)
					continue;

				Element vnr=(Element)vnr_list.item(0);
				hc.views=new HashMap<String, ViewConfig>();
				NodeList view_list=vnr.getElementsByTagName("view");
				for (int j=0; j<view_list.getLength(); j++){
					Element view=(Element)view_list.item(j);
					
					ViewConfig vc=new ViewConfig();
					vc.name=view.getAttribute("name");
					vc.template=view.getAttribute("template");
					
					vc.parts=new HashMap<String, String>();
					NodeList part_list=view.getElementsByTagName("part");
					for (int k=0; k<part_list.getLength(); k++){
						Element part=(Element)part_list.item(k);
						vc.parts.put(part.getAttribute("name"),part.getAttribute("value"));						
					}
					hc.views.put(vc.name,vc);
				}				
			}
			getServletContext().setAttribute(getInitParameter("configAttributeName"),sc);
		}
		catch(Exception e){
			e.printStackTrace();
			throw new ServletException();
		}
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		process(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		process(request, response);
	}

	private void process(HttpServletRequest request, HttpServletResponse response)
				throws ServletException, IOException {
		
		String path=request.getServletPath().substring(0,request.getServletPath().lastIndexOf("."));
		
		
		SiteConfig siteConfig=(SiteConfig)getServletContext().getAttribute(getInitParameter("configAttributeName"));
		
		if (!siteConfig.handlers.containsKey(path)){
			response.sendError(404);
			return;
		}
		
		HandlerConfig handlerConfig=siteConfig.handlers.get(path);
		//System.out.println (handlerConfig.handlerClass);
		if (handlerConfig.handlerClass==null || handlerConfig.handlerClass.equals("")){
			if (handlerConfig.page==null || handlerConfig.page.equals("")){
				//----------------------- 
				if (handlerConfig.views.isEmpty()){
					response.sendError(404);
					return;
				}
				ViewConfig vc=handlerConfig.views.get("view");
				dispatchRequestToView(siteConfig,vc,request,response);
			}
			else{
				RequestDispatcher rd=request.getRequestDispatcher(handlerConfig.page);
				rd.forward(request, response);				
			}
			return;
		}
			
		try{
			if (handlerConfig.handler==null)
				handlerConfig.createHandler();
		}catch(Exception e){
			e.printStackTrace();
			response.sendError(500, "Path found but cannot initialize handler");
		}
		Object requestData=null;
		try{
			
			if (handlerConfig.commandClass==null || handlerConfig.commandClass.equals(""))
				requestData=request.getParameterMap();
			else{
				if (handlerConfig.scope.equals("session")){
					requestData=request.getSession().getAttribute(handlerConfig.commandName);
					if (requestData==null){
						requestData=handlerConfig.createCommand();
						request.getSession().setAttribute(handlerConfig.commandName,requestData);
					}
				}
				else{
					requestData=handlerConfig.createCommand();
					request.setAttribute(handlerConfig.commandName, requestData);
				}
				//load data
				BeanUtils.populate(requestData, request.getParameterMap());
			}
		}catch(Exception e){
			//failed to create command object
			e.printStackTrace();
			response.sendError(500, "Failed to prepare Command object");
			return;
		}
		Result result=null;
		try{
			result=handlerConfig.invokeHandler(requestData);
		} catch(Exception e){
			e.printStackTrace();
			//can add exception handler
			System.out.println("Exception -------------------"+e.getClass().getName());
			if (handlerConfig.views.containsKey(e.getClass().getName()))
				result=new Result(e.getClass().getName(),"exception", e);
			else
				result=new Result("fail", "exception", e);
		}
		
		if (result==null)
			return;//request processing completed
		
		response.setContentType("text/html");
		prepareForPresentation(request, result);
		
		if (!handlerConfig.views.containsKey(result.viewName)){
			response.sendError(404, "Response View not found");
		}
		ViewConfig vc=handlerConfig.views.get(result.viewName);
		
		dispatchRequestToView(siteConfig, vc, request, response);
	}

	private void prepareForPresentation(HttpServletRequest request, Result result) {
		if (result.modelData==null || result.modelData.isEmpty())
			return;
		Set<Map.Entry<String, Object>> entries=(Set<Map.Entry<String, Object>>)result.modelData.entrySet();
		for (Map.Entry<String, Object> entry: entries){
			request.setAttribute(entry.getKey(),entry.getValue());
		}
	}
	
	private void dispatchRequestToView(SiteConfig siteConfig, ViewConfig vc, 
			HttpServletRequest request, HttpServletResponse response)
										throws ServletException, IOException {
		request.setAttribute("viewParts",vc.parts);
		
		RequestDispatcher rd=null;
		if (vc.template==null||vc.template.equals(""))
			rd=request.getRequestDispatcher(siteConfig.defaultTemplate);
		else
			rd=request.getRequestDispatcher(vc.template);
		if (rd==null){
			response.sendError(404, "Template not found");
			return;
		}
		rd.forward(request, response);		
	}

}

/**
 * 
 */
package com.santosh.hospital.controller;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Santosh
 *
 */
public class Result {
	
	public String viewName;
	public Map modelData;

	public Result() {}
	/**
	 * @param viewName
	 */
	public Result(String viewName) {
		this.viewName = viewName;
	}
	/**
	 * @param viewName
	 * @param modelData
	 */
	public Result(String viewName, Map modelData) {
		this.viewName = viewName;
		this.modelData = modelData;
	}
	public Result(String viewName, String name, Object value) {
		this.viewName = viewName;
		this.modelData = new HashMap();
		modelData.put(name, value);
	}	
}

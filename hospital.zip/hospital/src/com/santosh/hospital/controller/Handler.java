/**
 * 
 */
package com.santosh.hospital.controller;


/**
 * @author Santosh
 *
 */
public interface Handler {
	
	Result process(Object o)throws Exception;

}

/**
 * 
 */
package com.santosh.hospital.controller;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.santosh.hospital.model.AdminDetails;

/**
 * @author Santosh
 *
 */
public class SessionValidatorFilter implements Filter {

	/* (non-Javadoc)
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	public void init(FilterConfig arg0) throws ServletException {}

	/* (non-Javadoc)
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest, javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	public void doFilter(ServletRequest req, ServletResponse res,
			FilterChain fc) throws IOException, ServletException {

		String req_path=((HttpServletRequest)req).getServletPath();
		if (req_path.equals("/adminLogin.hm")
			|| req_path.equals("/adminLoginView.hm")
			|| req_path.equals("/home.hm")){
			
			fc.doFilter(req,res);
			return;
		}
		HttpSession hs=((HttpServletRequest)req).getSession();
		if (hs.isNew()
			||hs.getAttribute("userDetails")==null
			||((AdminDetails)hs.getAttribute("userDetails")).firstName==null
			||((AdminDetails)hs.getAttribute("userDetails")).firstName.equals(""))
		{
			//res.getWriter().println("<b>Please login before accessing the administrative services</b>");
			req.getRequestDispatcher("/adminLoginView.hm").forward(req, res);
			return;
		}
		fc.doFilter(req, res);
	}

	/* (non-Javadoc)
	 * @see javax.servlet.Filter#destroy()
	 */
	public void destroy() {}

}

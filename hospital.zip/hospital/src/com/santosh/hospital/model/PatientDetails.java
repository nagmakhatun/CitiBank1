/**
 * 
 */
package com.santosh.hospital.model;

/**
 * @author Santosh
 *
 */
public class PatientDetails {

	public String pass,suffix,firstName,lastName,gender,dob,socialSecNo,occupation,
	fax,email,smoking,drinker,patientAddress,city,state,zip,country,emgContactName, ellergies;

	public int patientId,homePhoneNo,workPhoneNo,emgContactPhone;

	/**
	 * @return Returns the city.
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city The city to set.
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return Returns the country.
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country The country to set.
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return Returns the dob.
	 */
	public String getDob() {
		return dob;
	}

	/**
	 * @param dob The dob to set.
	 */
	public void setDob(String dob) {
		this.dob = dob;
	}

	/**
	 * @return Returns the drinker.
	 */
	public String getDrinker() {
		return drinker;
	}

	/**
	 * @param drinker The drinker to set.
	 */
	public void setDrinker(String drinker) {
		this.drinker = drinker;
	}

	/**
	 * @return Returns the email.
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email The email to set.
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return Returns the emgContactName.
	 */
	public String getEmgContactName() {
		return emgContactName;
	}

	/**
	 * @param emgContactName The emgContactName to set.
	 */
	public void setEmgContactName(String emgContactName) {
		this.emgContactName = emgContactName;
	}

	/**
	 * @return Returns the emgContactPhone.
	 */
	public int getEmgContactPhone() {
		return emgContactPhone;
	}

	/**
	 * @param emgContactPhone The emgContactPhone to set.
	 */
	public void setEmgContactPhone(int emgContactPhone) {
		this.emgContactPhone = emgContactPhone;
	}

	/**
	 * @return Returns the fax.
	 */
	public String getFax() {
		return fax;
	}

	/**
	 * @param fax The fax to set.
	 */
	public void setFax(String fax) {
		this.fax = fax;
	}

	/**
	 * @return Returns the firstName.
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName The firstName to set.
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return Returns the gender.
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * @param gender The gender to set.
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	/**
	 * @return Returns the homePhoneNo.
	 */
	public int getHomePhoneNo() {
		return homePhoneNo;
	}

	/**
	 * @param homePhoneNo The homePhoneNo to set.
	 */
	public void setHomePhoneNo(int homePhoneNo) {
		this.homePhoneNo = homePhoneNo;
	}

	/**
	 * @return Returns the lastName.
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName The lastName to set.
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return Returns the occupation.
	 */
	public String getOccupation() {
		return occupation;
	}

	/**
	 * @param occupation The occupation to set.
	 */
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	/**
	 * @return Returns the patientAddress.
	 */
	public String getPatientAddress() {
		return patientAddress;
	}

	/**
	 * @param patientAddress The patientAddress to set.
	 */
	public void setPatientAddress(String patientAddress) {
		this.patientAddress = patientAddress;
	}

	/**
	 * @return Returns the pass.
	 */
	public String getPass() {
		return pass;
	}

	/**
	 * @param pass The pass to set.
	 */
	public void setPass(String pass) {
		this.pass = pass;
	}

	/**
	 * @return Returns the patientId.
	 */
	public int getPatientId() {
		return patientId;
	}

	/**
	 * @param patientId The patientId to set.
	 */
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	/**
	 * @return Returns the smoking.
	 */
	public String getSmoking() {
		return smoking;
	}

	/**
	 * @param smoking The smoking to set.
	 */
	public void setSmoking(String smoking) {
		this.smoking = smoking;
	}

	/**
	 * @return Returns the socialSecNo.
	 */
	public String getSocialSecNo() {
		return socialSecNo;
	}

	/**
	 * @param socialSecNo The socialSecNo to set.
	 */
	public void setSocialSecNo(String socialSecNo) {
		this.socialSecNo = socialSecNo;
	}

	/**
	 * @return Returns the state.
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state The state to set.
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return Returns the suffix.
	 */
	public String getSuffix() {
		return suffix;
	}

	/**
	 * @param suffix The suffix to set.
	 */
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	/**
	 * @return Returns the workPhoneNo.
	 */
	public int getWorkPhoneNo() {
		return workPhoneNo;
	}

	/**
	 * @param workPhoneNo The workPhoneNo to set.
	 */
	public void setWorkPhoneNo(int workPhoneNo) {
		this.workPhoneNo = workPhoneNo;
	}

	/**
	 * @return Returns the zip.
	 */
	public String getZip() {
		return zip;
	}

	/**
	 * @param zip The zip to set.
	 */
	public void setZip(String zip) {
		this.zip = zip;
	}

	/**
	 * @return Returns the ellergies.
	 */
	public String getEllergies() {
		return ellergies;
	}

	/**
	 * @param ellergies The ellergies to set.
	 */
	public void setEllergies(String ellergies) {
		this.ellergies = ellergies;
	}	
}

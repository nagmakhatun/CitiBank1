/**
 * 
 */
package com.santosh.hospital.model;

import java.io.Serializable;

/**
 * @author Santosh
 *
 */
public class MedicationDetails implements Serializable {
	
	public int medicationId;
	public String mnfName,medicName,availForm,cures,precautions,usage,sideEffect,description,added;
	public String[] medicForm,usefull;
	/**
	 * @return Returns the added.
	 */
	public String getAdded() {
		return added;
	}
	/**
	 * @param added The added to set.
	 */
	public void setAdded(String added) {
		this.added = added;
	}
	/**
	 * @return Returns the availForm.
	 */
	public String getAvailForm() {
		return availForm;
	}
	/**
	 * @param availForm The availForm to set.
	 */
	public void setAvailForm(String availForm) {
		this.availForm = availForm;
	}
	/**
	 * @return Returns the cures.
	 */
	public String getCures() {
		return cures;
	}
	/**
	 * @param cures The cures to set.
	 */
	public void setCures(String cures) {
		this.cures = cures;
	}
	/**
	 * @return Returns the description.
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description The description to set.
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return Returns the medicationId.
	 */
	public int getMedicationId() {
		return medicationId;
	}
	/**
	 * @param medicationId The medicationId to set.
	 */
	public void setMedicationId(int medicationId) {
		this.medicationId = medicationId;
	}
	/**
	 * @return Returns the medicForm.
	 */
	public String[] getMedicForm() {
		return medicForm;
	}
	/**
	 * @param medicForm The medicForm to set.
	 */
	public void setMedicForm(String[] medicForm) {
		this.medicForm = medicForm;
	}
	/**
	 * @return Returns the medicName.
	 */
	public String getMedicName() {
		return medicName;
	}
	/**
	 * @param medicName The medicName to set.
	 */
	public void setMedicName(String medicName) {
		this.medicName = medicName;
	}
	/**
	 * @return Returns the mnfName.
	 */
	public String getMnfName() {
		return mnfName;
	}
	/**
	 * @param mnfName The mnfName to set.
	 */
	public void setMnfName(String mnfName) {
		this.mnfName = mnfName;
	}
	/**
	 * @return Returns the precautions.
	 */
	public String getPrecautions() {
		return precautions;
	}
	/**
	 * @param precautions The precautions to set.
	 */
	public void setPrecautions(String precautions) {
		this.precautions = precautions;
	}
	/**
	 * @return Returns the sideEffect.
	 */
	public String getSideEffect() {
		return sideEffect;
	}
	/**
	 * @param sideEffect The sideEffect to set.
	 */
	public void setSideEffect(String sideEffect) {
		this.sideEffect = sideEffect;
	}
	/**
	 * @return Returns the usage.
	 */
	public String getUsage() {
		return usage;
	}
	/**
	 * @param usage The usage to set.
	 */
	public void setUsage(String usage) {
		this.usage = usage;
	}
	/**
	 * @return Returns the usefull.
	 */
	public String[] getUsefull() {
		return usefull;
	}
	/**
	 * @param usefull The usefull to set.
	 */
	public void setUsefull(String[] usefull) {
		this.usefull = usefull;
	}
	
	
}

/**
 * 
 */
package com.santosh.hospital.model;

import java.io.Serializable;

/**
 * @author Santosh
 *
 */
public class DoctorDetails implements Serializable {
	public String firstName,lastName,pass,qualification,otherQualification,specialization,otherSpecilization,dob,yearExp,expSummary,email,address;
	public int homePhone,officePhone,mobile,doctorId;
	/**
	 * @return Returns the address.
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @param address The address to set.
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	/**
	 * @return Returns the dob.
	 */
	public String getDob() {
		return dob;
	}
	/**
	 * @param dob The dob to set.
	 */
	public void setDob(String dob) {
		this.dob = dob;
	}
	/**
	 * @return Returns the doctorId.
	 */
	public int getDoctorId() {
		return doctorId;
	}
	/**
	 * @param doctorId The doctorId to set.
	 */
	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}
	/**
	 * @return Returns the email.
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email The email to set.
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return Returns the expSummary.
	 */
	public String getExpSummary() {
		return expSummary;
	}
	/**
	 * @param expSummary The expSummary to set.
	 */
	public void setExpSummary(String expSummary) {
		this.expSummary = expSummary;
	}
	/**
	 * @return Returns the firstName.
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName The firstName to set.
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return Returns the homePhone.
	 */
	public int getHomePhone() {
		return homePhone;
	}
	/**
	 * @param homePhone The homePhone to set.
	 */
	public void setHomePhone(int homePhone) {
		this.homePhone = homePhone;
	}
	/**
	 * @return Returns the lastName.
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName The lastName to set.
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return Returns the mobile.
	 */
	public int getMobile() {
		return mobile;
	}
	/**
	 * @param mobile The mobile to set.
	 */
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	/**
	 * @return Returns the officePhone.
	 */
	public int getOfficePhone() {
		return officePhone;
	}
	/**
	 * @param officePhone The officePhone to set.
	 */
	public void setOfficePhone(int officePhone) {
		this.officePhone = officePhone;
	}
	/**
	 * @return Returns the otherQualification.
	 */
	public String getOtherQualification() {
		return otherQualification;
	}
	/**
	 * @param otherQualification The otherQualification to set.
	 */
	public void setOtherQualification(String otherQualification) {
		this.otherQualification = otherQualification;
	}
	/**
	 * @return Returns the otherSpecilization.
	 */
	public String getOtherSpecilization() {
		return otherSpecilization;
	}
	/**
	 * @param otherSpecilization The otherSpecilization to set.
	 */
	public void setOtherSpecilization(String otherSpecilization) {
		this.otherSpecilization = otherSpecilization;
	}
	/**
	 * @return Returns the pass.
	 */
	public String getPass() {
		return pass;
	}
	/**
	 * @param pass The pass to set.
	 */
	public void setPass(String pass) {
		this.pass = pass;
	}
	/**
	 * @return Returns the qualification.
	 */
	public String getQualification() {
		return qualification;
	}
	/**
	 * @param qualification The qualification to set.
	 */
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	/**
	 * @return Returns the specilization.
	 */
	public String getSpecialization() {
		return specialization;
	}
	/**
	 * @param specilization The specilization to set.
	 */
	public void setSpecialization(String specilization) {
		this.specialization = specilization;
	}
	/**
	 * @return Returns the yearExp.
	 */
	public String getYearExp() {
		return yearExp;
	}
	/**
	 * @param yearExp The yearExp to set.
	 */
	public void setYearExp(String yearExp) {
		this.yearExp = yearExp;
	}
	

}

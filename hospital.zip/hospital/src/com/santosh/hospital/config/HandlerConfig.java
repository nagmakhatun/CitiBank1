
package com.santosh.hospital.config;

import java.util.HashMap;

import com.santosh.hospital.controller.Handler;
import com.santosh.hospital.controller.Result;

/**
 * @author Santosh
 *
 */
public class HandlerConfig {

	public String path;
	public String page;
	public String handlerClass;
	public String commandClass;
	public HashMap<String, ViewConfig> views;
	public Handler handler;
	public String scope;
	public String commandName;
	
	
	/**
	 * @param commandName The commandName to set.
	 */
	public void setCommandName(String commandName) {
		if (commandName.equals("")){
			if (!commandClass.equals("")){
				try{
					this.commandName=Class.forName(commandClass).getSimpleName();
				}catch(Exception e){
					this.commandName="defaultCommandName";
				}
			}
		}
		else
			this.commandName = commandName;
		
//		System.out.print(this.commandName);
	}
	/**
	 * @param scope The scope to set.
	 */
	public void setScope(String scope) {
		if (scope.equals(""))
			this.scope="request";
		else
			this.scope = scope;
	}
	
	public void createHandler() throws Exception{
		handler=(Handler)Class.forName(handlerClass).newInstance();
	}
	public Object createCommand()throws Exception {
		return Class.forName(commandClass).newInstance();
	}
	
	public Result invokeHandler(Object o)throws Exception{
		return handler.process(o);
	}	
}

/**
 * 
 */
package com.santosh.hospital.config;

import java.util.HashMap;

/**
 * @author Santosh
 *
 */
public class SiteConfig {

	public HashMap<String, HandlerConfig> handlers;
	public String defaultTemplate;
	public ViewConfig defaultView;
	/**
	 * @return Returns the defaultView.
	 */
	public ViewConfig getDefaultView() {
		return defaultView;
	}

}

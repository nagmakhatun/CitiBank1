/**
 * 
 */
package com.santosh.hospital.config;

import java.util.HashMap;

/**
 * @author Santosh
 *
 */
public class ViewConfig {

	public ViewConfig(){}
//	public ViewConfig(String s){name=s;}
	
	public HashMap<String, String> parts;
	public String name;
	public String template;
	/**
	 * @return Returns the parts.
	 */
	public HashMap<String, String> getParts() {
		return parts;
	}
	
/*	
	public boolean equals(Object o){
		if (o instanceof ViewConfig)
			return name.equals(((ViewConfig)o).name);
		return false;
	}
	*/
}

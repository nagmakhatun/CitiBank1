/**
 * 
 */
package com.santosh.hospital.dao;

/**
 * @author Santosh
 *
 */
public abstract class DAOFactory {
	
	public static DAOFactory getDAOFactory(){
		return new JdbcDAOFactory();		
	}
	
	public abstract AdminDetailsDAO getAdminDetailsDAO();
	public abstract PatientDAO getPatientDAO();
	public abstract DoctorDAO getDoctorDAO();

	public abstract MedicationDAO getMedicationDAO();
}

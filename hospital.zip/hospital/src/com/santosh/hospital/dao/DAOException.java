/**
 * 
 */
package com.santosh.hospital.dao;

/**
 * @author Santosh
 *
 */
public class DAOException extends RuntimeException {
	public DAOException(){}
	public DAOException(String message){super(message);}
}

/**
 * 
 */
package com.santosh.hospital.dao.util;

import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * @author Santosh
 *
 */
public interface ParametersSetter {
	public void setValues(PreparedStatement ps)throws SQLException;

}

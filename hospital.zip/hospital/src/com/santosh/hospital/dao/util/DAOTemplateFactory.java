/**
 * 
 */
package com.santosh.hospital.dao.util;

//import javax.naming.InitialContext;
//import javax.sql.DataSource;

import oracle.jdbc.pool.OracleConnectionPoolDataSource;

import com.santosh.hospital.dao.DAOException;

/**
 * @author Santosh
 *
 */
public abstract class DAOTemplateFactory {
	
	static {
		prepareDataSource();
	}
	private static void prepareDataSource(){
		try{
			ds=new OracleConnectionPoolDataSource();
			ds.setURL("jdbc:oracle:thin:@localhost:1521:sandb");
			ds.setUser("hospital");
			ds.setPassword("hospital");
		}catch(Exception e){
			e.printStackTrace();
			throw new RuntimeException("Unable to prepare DataSource");
		}
	} 
	public static DAOTemplate newDAOTemplate(){
		try{
			//InitialContext ic=new InitialContext();
			//DataSource ds=(DataSource)ic.lookup("java:comp/env/HMDataSource");
			
			return new JdbcTemplate(ds);
		}
		catch(Exception e){
			//to-do exception handlng
			e.printStackTrace();
			throw new DAOException();
		}
		
	}
	private static OracleConnectionPoolDataSource ds;
}

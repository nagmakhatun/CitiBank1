/**
 * 
 */
package com.santosh.hospital.dao.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import com.santosh.hospital.dao.DAOException;

/**
 * @author Santosh
 *
 */
public class JdbcTemplate implements DAOTemplate{
	
	private DataSource dataSource;
	
	public JdbcTemplate(DataSource ds){
		dataSource=ds;
	}
	
	/* (non-Javadoc)
	 * @see com.santosh.hospital.dao.util.DAOTemplate#findForString(java.lang.String)
	 */
	public int findForInt(String query){
		Connection con=null;
		try {
			con=dataSource.getConnection();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(query);
			if (rs.next())
				return rs.getInt(1);
			return -1;
		}
		catch(SQLException e){
			//to-do exception handling
		}
		finally {
			try{
				con.close();
			}catch(SQLException e){
				//to-do exception handling
			}
		}
		throw new DAOException();
	}
	
	/* (non-Javadoc)
	 * @see com.santosh.hospital.dao.util.DAOTemplate#findForString(java.lang.String)
	 */
	public String findForString(String query){
		Connection con=null;
		try {
			con=dataSource.getConnection();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(query);
			if (rs.next())
				return rs.getString(1);
			return null;
		}
		catch(SQLException e){
			//to-do exception handling
		}
		finally {
			try{
				con.close();
			}catch(SQLException e){
				//to-do exception handling
			}
		}
		throw new DAOException();
	}
	
	/* (non-Javadoc)
	 * @see com.santosh.hospital.dao.util.DAOTemplate#findForObject(java.lang.String)
	 */
	public Object findForObject(String query){
		Connection con=null;
		try {
			con=dataSource.getConnection();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(query);
			if (rs.next())
				return rs.getObject(1);
			return null;
		}
		catch(SQLException e){
			//to-do exception handling
		}
		finally {
			try{
				con.close();
			}catch(SQLException e){
				//to-do exception handling
			}
		}
		throw new DAOException();
	}
	/* (non-Javadoc)
	 * @see com.santosh.hospital.dao.util.DAOTemplate#findForObject(java.lang.String, com.santosh.hospital.dao.util.Mapper)
	 */
	public Object findForObject(String query, Mapper m){
		Connection con=null;
		try {
			con=dataSource.getConnection();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(query);
			if (rs.next())
				return m.map(rs);
			return null;
		}
		catch(SQLException e){
			//to-do exception handling
		}
		finally {
			try{
				con.close();
			}catch(SQLException e){
				//to-do exception handling
			}
		}
		throw new DAOException();
	}
	/* (non-Javadoc)
	 * @see com.santosh.hospital.dao.util.DAOTemplate#find(java.lang.String, com.santosh.hospital.dao.util.Mapper)
	 */
	public List find(String query, Mapper m){
		Connection con=null;
		try {
			con=dataSource.getConnection();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(query);
			ArrayList result=new ArrayList();
			while (rs.next())
				result.add(m.map(rs));
			return result;
		}
		catch(SQLException e){
			//to-do exception handling
			e.printStackTrace();
		}
		finally {
			try{
				con.close();
			}catch(SQLException e){
				//to-do exception handling
			}
		}
		throw new DAOException();
	}
	/* (non-Javadoc)
	 * @see com.santosh.hospital.dao.util.DAOTemplate#update(java.lang.String, com.santosh.hospital.dao.util.ParametersSetter)
	 */
	public int update(String st, ParametersSetter s){
		Connection con=null;
		try {
			con=dataSource.getConnection();
			PreparedStatement ps=con.prepareStatement(st);
			s.setValues(ps);
			int i=ps.executeUpdate();
			return i;
		}
		catch(SQLException e){
			//to-do exception handling
			e.printStackTrace();
		}
		finally {
			try{
				con.close();
			}catch(SQLException e){
				//to-do exception handling
			}
		}
		throw new DAOException();
	}

	public int update(String st) {
		Connection con=null;
		try {
			con=dataSource.getConnection();
			Statement statement=con.createStatement();
			int i=statement.executeUpdate(st);
			return i;
		}
		catch(SQLException e){
			//to-do exception handling
			e.printStackTrace();
		}
		finally {
			try{
				con.close();
			}catch(SQLException e){
				//to-do exception handling
			}
		}
		throw new DAOException();
	}
}

//removed methods
/*	
public int createWithSequence(String sql_st, ParametersSetter ps){
	Connection con=null;
	try {
		con=dataSource.getConnection();
		Statement st=con.createStatement();
		int i=st.executeUpdate(sql_st);//,Statement.RETURN_GENERATED_KEYS);
		//ResultSet rs=st.getGeneratedKeys();
		//System.out.println(rs.next());
		//System.out.println(rs.getString(1));
		return i;
	}
	catch(SQLException e){
		e.printStackTrace();
		//to-do exception handling
	}
	finally {
		try{
			con.close();
		}catch(SQLException e){
			//to-do exception handling
		}
	}
	throw new DAOException();
}

public int create(String sql_st, ParametersSetter ps){
	Connection con=null;
	try {
		con=dataSource.getConnection();
		PreparedStatement pst=con.prepareStatement(sql_st);
		ps.setValues(pst);
		int i=pst.executeUpdate();
		return i;
	}
	catch(SQLException e){
		e.printStackTrace();
		//to-do exception handling
	}
	finally {
		try{
			con.close();
		}catch(SQLException e){
			//to-do exception handling
		}
	}
	throw new DAOException();
}
*/		
/*
public int getNextId(String sequence_name){
	Connection con=null;
	try{
		con=dataSource.getConnection();
		Statement st=con.createStatement();
		ResultSet 
	}
}
*/
/*
public static void main(String s[])throws Exception {
	OracleConnectionPoolDataSource ocp=new OracleConnectionPoolDataSource();
	ocp.setURL("jdbc:oracle:thin:@localhost:1521:sandb");
	ocp.setUser("disp");
	ocp.setPassword("disp");
	JdbcTemplate jt=new JdbcTemplate(ocp);
	
	System.out.println(jt.createWithSequence("insert into admindetails(userId) values(adminid.nextVal)", new ParametersSetter(){
		public void setValues(PreparedStatement ps){}
	}));
	
}*/


package com.santosh.hospital.dao.util;

import java.util.List;

public interface DAOTemplate {

	/* (non-Javadoc)
	 * @see com.santosh.hospital.dao.util.DAOTemplate#findForInt(java.lang.String)
	 */
	public abstract int findForInt(String query);

	/* (non-Javadoc)
	 * @see com.santosh.hospital.dao.util.DAOTemplate#findForString(java.lang.String)
	 */
	public abstract String findForString(String query);

	/* (non-Javadoc)
	 * @see com.santosh.hospital.dao.util.DAOTemplate#findForObject(java.lang.String)
	 */
	public abstract Object findForObject(String query);

	/* (non-Javadoc)
	 * @see com.santosh.hospital.dao.util.DAOTemplate#findForObject(java.lang.String, com.santosh.hospital.dao.util.Mapper)
	 */
	public abstract Object findForObject(String query, Mapper m);

	/* (non-Javadoc)
	 * @see com.santosh.hospital.dao.util.DAOTemplate#find(java.lang.String, com.santosh.hospital.dao.util.Mapper)
	 */
	public abstract List find(String query, Mapper m);

	public abstract int update(String st);
	public abstract int update(String st, ParametersSetter s);
	
//	public abstract int createWithSequence(String st, ParametersSetter s);
//	public abstract int create(String sql_st, ParametersSetter ps);

}
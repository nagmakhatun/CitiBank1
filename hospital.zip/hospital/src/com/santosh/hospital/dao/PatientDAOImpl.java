/**
 * 
 */
package com.santosh.hospital.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.santosh.hospital.dao.util.DAOTemplate;
import com.santosh.hospital.dao.util.DAOTemplateFactory;
import com.santosh.hospital.dao.util.Mapper;
import com.santosh.hospital.dao.util.ParametersSetter;
import com.santosh.hospital.model.PatientDetails;

/**
 * @author Santosh
 *
 */
public class PatientDAOImpl implements PatientDAO {

	DAOTemplate daoTemplate;
	
	public PatientDAOImpl(){
		daoTemplate=DAOTemplateFactory.newDAOTemplate();
	}
	
	/* (non-Javadoc)
	 * @see com.santosh.hospital.dao.PatientDAO#createPatient(com.santosh.hospital.model.PatientDetails)
	 */
	public void createPatient(final PatientDetails pd){
		
		pd.patientId=daoTemplate.findForInt("select patientIdSeq.nextVal from dual");

		if (pd.patientId==-1) throw new DAOException("Failed to generate Patient ID");
		
		daoTemplate.update("insert into patient_details values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", 
				new ParametersSetter(){
			public void setValues(PreparedStatement ps) throws SQLException{
				ps.setInt(1,pd.patientId);
				ps.setString(2, pd.pass);
				ps.setString(3, pd.suffix);
				ps.setString(4, pd.firstName);
				ps.setString(5, pd.lastName);
				ps.setString(6, pd.gender);
				ps.setString(7, pd.dob);
				ps.setString(8, pd.socialSecNo);
				ps.setString(9, pd.occupation);
				ps.setInt(10, pd.homePhoneNo);
				ps.setInt(11, pd.workPhoneNo);
				ps.setString(12, pd.fax);
				ps.setString(13, pd.email);
				ps.setString(14, pd.smoking);
				ps.setString(15, pd.drinker);
				ps.setString(16, pd.patientAddress);
				ps.setString(17, pd.city);
				ps.setString(18, pd.state);
				ps.setString(19, pd.zip);
				ps.setString(20, pd.country);
				ps.setString(21, pd.emgContactName);
				ps.setInt(22, pd.emgContactPhone);
			}
		});		
		createEllergies(pd.patientId, pd.ellergies);
	}
	
	/* (non-Javadoc)
	 * @see com.santosh.hospital.dao.PatientDAO#createEllergies(int, java.lang.String)
	 */
	public void createEllergies(final int patientId, final String ellergies){
		
		daoTemplate.update("insert into ELLERGIES_DETAILS values(?,?)", 
				new ParametersSetter(){
			public void setValues(PreparedStatement ps)throws SQLException{
				ps.setInt(1, patientId);
				ps.setString(2, ellergies);
			}
		});
	}
	/*
	public void changePatient(PatientDetails pd){
		daoTemplate.update("update patient_details set ");
	}
	*/

	public void remove(String patientId) {
		
		int i=daoTemplate.update("delete from patient_details where patient_id="+patientId);
		if (i==1){
			i=daoTemplate.update("delete from ellergies_details where patient_id="+patientId);
			if (i==1) return;
		}
		throw new DAOException("Failed to delete the record from database. \nPossible reason: Given patientId "+patientId+" may not be found");
	}

	public PatientDetails getPatientById(int patientId) {
		return (PatientDetails)daoTemplate.findForObject(
				"select pd.*, e.list_of_ellergies from patient_details pd, ellergies_details e where pd.patient_id="+patientId+" and e.patient_id="+patientId, 
				new Mapper(){
			public Object map(ResultSet rs)throws SQLException{
				PatientDetails pd=new PatientDetails();
				pd.patientId=rs.getInt(1);		
				pd.pass=rs.getString(2);	
				pd.suffix=rs.getString(3);	
				pd.firstName=rs.getString(4);	
				pd.lastName=rs.getString(5);	
				pd.gender=rs.getString(6);	
				pd.dob=rs.getString(7);	
				pd.socialSecNo=rs.getString(8);	
				pd.occupation=rs.getString(9);	
				pd.homePhoneNo=rs.getInt(10);		
				pd.workPhoneNo=rs.getInt(11);		
				pd.fax=rs.getString(12);	
				pd.email=rs.getString(13);	
				pd.smoking=rs.getString(14);	
				pd.drinker=rs.getString(15);	
				pd.patientAddress=rs.getString(16);	
				pd.city=rs.getString(17);	
				pd.state=rs.getString(18);	
				pd.zip=rs.getString(19);	
				pd.country=rs.getString(20);	
				pd.emgContactName=rs.getString(21);	
				pd.emgContactPhone=rs.getInt(22);
				pd.ellergies=rs.getString(23);
				return pd;
			}
		});
	}

	public List<PatientDetails> getPatientByName(String name) {
		return (List<PatientDetails>)daoTemplate.find(
				"select patient_id, first_Name,dob, occupation, email, social_sec_no from patient_details where first_name like \'"+name+"\'", 
				new Mapper(){
			public Object map(ResultSet rs)throws SQLException{
				PatientDetails pd=new PatientDetails();
				pd.patientId=rs.getInt(1);		
				pd.firstName=rs.getString(2);	
				pd.dob=rs.getString(3);	
				pd.occupation=rs.getString(4);	
				pd.email=rs.getString(5);	
				pd.socialSecNo=rs.getString(6);	
				return pd;
			}
		});
	}

	public List<PatientDetails> getPatientByLocation(String location) {
		return (List<PatientDetails>)daoTemplate.find(
				"select patient_id, first_Name,dob, occupation, email, social_sec_no  from patient_details where city like \'"+location+"\'", 
				new Mapper(){
			public Object map(ResultSet rs)throws SQLException{
				PatientDetails pd=new PatientDetails();
				pd.patientId=rs.getInt(1);		
				pd.firstName=rs.getString(2);	
				pd.dob=rs.getString(3);	
				pd.occupation=rs.getString(4);	
				pd.email=rs.getString(5);	
				pd.socialSecNo=rs.getString(6);	
				return pd;
			}
		});
	}
}

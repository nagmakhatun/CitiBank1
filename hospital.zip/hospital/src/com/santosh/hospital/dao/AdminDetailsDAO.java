package com.santosh.hospital.dao;

import com.santosh.hospital.model.AdminDetails;

public interface AdminDetailsDAO {

	public abstract boolean find(AdminDetails ad);

	public void create(final AdminDetails ad);
}
/**
 * 
 */
package com.santosh.hospital.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.santosh.hospital.dao.util.DAOTemplate;
import com.santosh.hospital.dao.util.DAOTemplateFactory;
import com.santosh.hospital.dao.util.Mapper;
import com.santosh.hospital.dao.util.ParametersSetter;
import com.santosh.hospital.model.AdminDetails;

/**
 * @author Santosh
 *
 */
public class AdminDetailsDAOImpl implements AdminDetailsDAO {
	DAOTemplate daoTemplate;
	
	public AdminDetailsDAOImpl(){
		daoTemplate=DAOTemplateFactory.newDAOTemplate();		
	}
	
	/* (non-Javadoc)
	 * @see com.santosh.hospital.dao.AdminDetailsDAO#find(int, java.lang.String)
	 */
	public boolean find(final AdminDetails ad){
		Object o=daoTemplate.findForObject(
				"select * from admindetails where userid="+ad.userId+" and password=\'"+ad.pass+"\'",
				new Mapper(){
					public Object map(ResultSet rs)throws SQLException{
						ad.firstName=rs.getString(3);
						ad.lastName=rs.getString(4);
						ad.address=rs.getString(5);
						ad.phno=rs.getString(6);
						ad.email=rs.getString(7);
						return ad;
					}
				}
			);
		if (o==null)return false;
		return true;
	}
	public void create(final AdminDetails ad){
		ad.userId=daoTemplate.findForInt("select adminIdSeq.nextVal from dual");

		if (ad.userId==-1) throw new DAOException("Failed to generate Admin ID");
		
		daoTemplate.update("insert into admindetails values(?,?,?,?,?,?,?)", 
				new ParametersSetter(){
			public void setValues(PreparedStatement ps)throws SQLException{
				ps.setInt(1,ad.userId);
				ps.setString(2,ad.pass);
				ps.setString(3,ad.firstName);
				ps.setString(4,ad.lastName);
				ps.setString(5, ad.address);
				ps.setString(6, ad.phno);
				ps.setString(7,ad.email);
			}
		});
	}	
}

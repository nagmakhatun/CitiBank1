/**
 * 
 */
package com.santosh.hospital.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.santosh.hospital.dao.util.DAOTemplate;
import com.santosh.hospital.dao.util.DAOTemplateFactory;
import com.santosh.hospital.dao.util.Mapper;
import com.santosh.hospital.dao.util.ParametersSetter;
import com.santosh.hospital.model.MedicationDetails;

/**
 * @author Santosh
 *
 */
public class MedicationDAOImpl implements MedicationDAO {

	DAOTemplate daoTemplate;
	
	public MedicationDAOImpl(){
		daoTemplate=DAOTemplateFactory.newDAOTemplate();
	}

	/* (non-Javadoc)
	 * @see com.santosh.hospital.dao.MedicationDAO#createMedication(com.santosh.hospital.model.MedicationDetails)
	 */
	public void createMedication(final MedicationDetails md) {
		md.medicationId=daoTemplate.findForInt("select medicationIdSeq.nextVal from dual");

		if (md.medicationId==-1) throw new DAOException("Failed to generate Medicaton ID");
		
		daoTemplate.update("insert into medication_rep values(?,?,?,?,?,?,?,?,?,?,?,?)", 
				new ParametersSetter(){
			public void setValues(PreparedStatement ps) throws SQLException{
				ps.setInt(1,md.medicationId);
				ps.setString(2, md.mnfName);
				ps.setString(3, md.medicName);
				String medicForm="";
				if (md.medicForm!=null){
					for (int i=0;i<md.medicForm.length-1;i++)
						medicForm+=md.medicForm[i]+",";
					if (md.medicForm.length!=0)
						medicForm+=md.medicForm[md.medicForm.length-1];
				}
				ps.setString(4, medicForm);
				md.medicForm=new String[]{medicForm};
				ps.setString(5, md.availForm);
				ps.setString(6, md.cures);
				ps.setString(7, md.precautions);
				ps.setString(8, md.usage);
				ps.setString(9, md.sideEffect);
				
				String usefull="";
				if (md.usefull!=null){
					for (int i=0;i<md.usefull.length-1;i++)
						usefull+=md.usefull[i]+",";
					if (md.usefull.length!=0)
						usefull+=md.usefull[md.usefull.length-1];
				}
				md.usefull=new String[]{usefull};
				ps.setString(10, usefull);
				ps.setString(11, md.description);
				ps.setString(12, md.added);
			}
		});
	}

	/* (non-Javadoc)
	 * @see com.santosh.hospital.dao.MedicationDAO#remove(java.lang.String)
	 */
	public void remove(String medicationId) {
		
		int i=daoTemplate.update("delete from medication_rep where medicationid="+medicationId);
			if (i==1) return;
		
		throw new DAOException("Failed to delete the record from database. \nPossible reason: Given medicationId "+medicationId+" may not be found");
	}

	/* (non-Javadoc)
	 * @see com.santosh.hospital.dao.MedicationDAO#getMedicationById(int)
	 */
	public MedicationDetails getMedicationById(int mid) {
		return (MedicationDetails)daoTemplate.findForObject(
				"select * from medication_rep where medicationid="+mid, 
				new Mapper(){
			public Object map(ResultSet rs)throws SQLException{
				MedicationDetails md=new MedicationDetails();
				md.medicationId=rs.getInt(1);
				md.mnfName=rs.getString(2);
				md.medicName=rs.getString(3);
				md.medicForm=new String[]{rs.getString(4)};
				md.availForm=rs.getString(5);
				md.cures=rs.getString(6);
				md.precautions=rs.getString(7);
				md.usage=rs.getString(8);
				md.sideEffect=rs.getString(9);
				md.usefull=new String[]{rs.getString(10)};
				md.description=rs.getString(11);
				md.added=rs.getString(12);
				return md;
			}
		});
	}

	/* (non-Javadoc)
	 * @see com.santosh.hospital.dao.MedicationDAO#getMedicationByName(java.lang.String)
	 */
	public List<MedicationDetails> getMedicationByName(String name) {
		return (List<MedicationDetails>)daoTemplate.find(
				"select * from medication_rep where medic_name like \'"+name+"\'",
				new Mapper(){
			public Object map(ResultSet rs)throws SQLException{
				MedicationDetails md=new MedicationDetails();
				md.medicationId=rs.getInt(1);
				md.mnfName=rs.getString(2);
				md.medicName=rs.getString(3);
				md.medicForm=new String[] {rs.getString(4)};
				md.availForm=rs.getString(5);
				md.cures=rs.getString(6);
				md.precautions=rs.getString(7);
				md.usage=rs.getString(8);
				md.sideEffect=rs.getString(9);
				md.usefull=new String[]{rs.getString(10)};
				md.description=rs.getString(11);
				md.added=rs.getString(12);
				return md;
			}
		});
	}
}

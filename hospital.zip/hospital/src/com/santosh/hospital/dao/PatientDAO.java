package com.santosh.hospital.dao;

import java.util.List;

import com.santosh.hospital.model.PatientDetails;

public interface PatientDAO {

	public abstract void createPatient(final PatientDetails pd);

	public abstract void createEllergies(final int patientId,
			final String ellergies);
	/*
	 public void changePatient(PatientDetails pd){
	 daoTemplate.update("update patient_details set ");
	 }
	 */

	public abstract void remove(String patientId);

	public abstract PatientDetails getPatientById(int pid);

	public abstract List<PatientDetails> getPatientByName(String name);

	public abstract List<PatientDetails> getPatientByLocation(String loc);

}
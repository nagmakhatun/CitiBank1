/**
 * 
 */
package com.santosh.hospital.dao;

/**
 * @author Santosh
 *
 */
public class JdbcDAOFactory extends DAOFactory {

	/* (non-Javadoc)
	 * @see com.santosh.hospital.dao.DAOFactory#getAdminDetailsDAO()
	 */
	@Override
	public AdminDetailsDAO getAdminDetailsDAO() {
		return new AdminDetailsDAOImpl();
	}

	/* (non-Javadoc)
	 * @see com.santosh.hospital.dao.DAOFactory#getPatientDAO()
	 */
	@Override
	public PatientDAO getPatientDAO() {
		return new PatientDAOImpl();
	}

	@Override
	public DoctorDAO getDoctorDAO() {
		return new DoctorDAOImpl();
	}

	@Override
	public MedicationDAO getMedicationDAO() {
		return new MedicationDAOImpl();
	}

}

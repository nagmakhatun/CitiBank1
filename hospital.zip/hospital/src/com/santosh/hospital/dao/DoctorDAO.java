package com.santosh.hospital.dao;

import java.util.List;

import com.santosh.hospital.model.DoctorDetails;

public interface DoctorDAO {

	public abstract void createDoctor(final DoctorDetails dd);

	public abstract void remove(String doctorId);

	public abstract DoctorDetails getDoctorById(int did);
	public abstract List<DoctorDetails> getDoctorByName(String name);
	public abstract List<DoctorDetails> getDoctorBySpecialization(String spe);	
}
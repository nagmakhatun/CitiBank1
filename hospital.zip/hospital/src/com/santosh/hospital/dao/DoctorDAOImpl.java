/**
 * 
 */
package com.santosh.hospital.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.santosh.hospital.dao.util.DAOTemplate;
import com.santosh.hospital.dao.util.DAOTemplateFactory;
import com.santosh.hospital.dao.util.Mapper;
import com.santosh.hospital.dao.util.ParametersSetter;
import com.santosh.hospital.model.DoctorDetails;

/**
 * @author Santosh
 *
 */
public class DoctorDAOImpl implements DoctorDAO {

	DAOTemplate daoTemplate;
	
	public DoctorDAOImpl(){
		daoTemplate=DAOTemplateFactory.newDAOTemplate();
	}
	
	/* (non-Javadoc)
	 * @see com.santosh.hospital.dao.DoctorDAO#createDoctor(com.santosh.hospital.model.DoctorDetails)
	 */
	public void createDoctor(final DoctorDetails dd) {
		dd.doctorId=daoTemplate.findForInt("select doctorIdSeq.nextVal from dual");

		if (dd.doctorId==-1) throw new DAOException("Failed to generate Doctor ID");
		
		daoTemplate.update("insert into doctor_details values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", 
				new ParametersSetter(){
			public void setValues(PreparedStatement ps) throws SQLException{
				ps.setInt(1,dd.doctorId);
				ps.setString(2, dd.firstName);
				ps.setString(3, dd.lastName);
				ps.setString(4, dd.pass);
				ps.setString(5, dd.qualification);
				ps.setString(6, dd.otherQualification);
				ps.setString(7, dd.specialization);
				ps.setString(8, dd.otherSpecilization);
				ps.setString(9, dd.dob);
				ps.setString(10, dd.yearExp);
				ps.setString(11, dd.expSummary);
				ps.setString(12, dd.email);
				ps.setInt(13, dd.homePhone);
				ps.setInt(14, dd.officePhone);
				ps.setInt(15, dd.mobile);
				ps.setString(16, dd.address);
			}
		});
	}

	/* (non-Javadoc)
	 * @see com.santosh.hospital.dao.DoctorDAO#remove(java.lang.String)
	 */
	public void remove(String doctorId) {
		int i=daoTemplate.update("delete from doctor_details where doctor_id="+doctorId);
		if (i==1) return;
		
		throw new DAOException("Failed to delete the record from database. \nPossible reason: Given doctorId "+doctorId+" may not be found");
	}

	/* (non-Javadoc)
	 * @see com.santosh.hospital.dao.DoctorDAO#getDoctorById(int)
	 */
	public DoctorDetails getDoctorById(int did) {
		return (DoctorDetails)daoTemplate.findForObject(
				"select * from doctor_details where doctor_id="+did, 
				new Mapper(){
			public Object map(ResultSet rs)throws SQLException{
				DoctorDetails dd=new DoctorDetails();
				dd.doctorId=rs.getInt(1);    
				dd.firstName=rs.getString(2); 
				dd.lastName=rs.getString(3); 
				dd.pass=rs.getString(4); 
				dd.qualification=rs.getString(5); 
				dd.otherQualification=rs.getString(6); 
				dd.specialization=rs.getString(7); 
				dd.otherSpecilization=rs.getString(8); 
				dd.dob=rs.getString(9); 
				dd.yearExp=rs.getString(10);
				dd.expSummary=rs.getString(11);
				dd.email=rs.getString(12);
				dd.homePhone=rs.getInt(13);   
				dd.officePhone=rs.getInt(14);   
				dd.mobile=rs.getInt(15);   
				dd.address=rs.getString(16);
				return dd;
			}
		});	
	}

	/* (non-Javadoc)
	 * @see com.santosh.hospital.dao.DoctorDAO#getDoctorByName(java.lang.String)
	 */
	public List<DoctorDetails> getDoctorByName(String name) {
		return (List<DoctorDetails>)daoTemplate.find(
				"select doctor_id, firstName, qualification, specilization, dob, email from doctor_details where firstName like \'"+name+"\'", 
				new Mapper(){
			public Object map(ResultSet rs)throws SQLException{
				DoctorDetails dd=new DoctorDetails();
				dd.doctorId=rs.getInt(1);    
				dd.firstName=rs.getString(2); 
				dd.qualification=rs.getString(3); 
				dd.specialization=rs.getString(4); 
				dd.dob=rs.getString(5); 
				dd.email=rs.getString(6);
				return dd;
			}
		});	
	}

	/* (non-Javadoc)
	 * @see com.santosh.hospital.dao.DoctorDAO#getDoctorBySpecialization(java.lang.String)
	 */
	public List<DoctorDetails> getDoctorBySpecialization(String spe) {
		return (List<DoctorDetails>)daoTemplate.find(
				"select doctor_id, firstName, qualification, specilization, dob, email from doctor_details where specilization=\'"+spe+"\' or otherSpecilization=\'"+spe+"\'", 
				new Mapper(){
			public Object map(ResultSet rs)throws SQLException{
				DoctorDetails dd=new DoctorDetails();
				dd.doctorId=rs.getInt(1);    
				dd.firstName=rs.getString(2); 
				dd.qualification=rs.getString(3); 
				dd.specialization=rs.getString(4); 
				dd.dob=rs.getString(5); 
				dd.email=rs.getString(6);
				return dd;
			}
		});
	}
}

/**
 * 
 */
package com.santosh.hospital.dao;

import java.util.List;

import com.santosh.hospital.model.MedicationDetails;

/**
 * @author Santosh
 *
 */
public interface MedicationDAO {
	
	public abstract void createMedication(final MedicationDetails md);

	public abstract void remove(String medicationId);

	public abstract MedicationDetails getMedicationById(int mid);
	public abstract List<MedicationDetails> getMedicationByName(String name);
}

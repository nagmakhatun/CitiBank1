/**
 * 
 */
package com.santosh.hospital.handlers;

import java.util.List;
import java.util.Map;

import com.santosh.hospital.controller.Handler;
import com.santosh.hospital.controller.Result;
import com.santosh.hospital.dao.DAOFactory;
import com.santosh.hospital.dao.PatientDAO;
import com.santosh.hospital.model.PatientDetails;

/**
 * @author Santosh
 *
 */
public class SearchPatientHandler implements Handler {

	/* (non-Javadoc)
	 * @see com.santosh.hospital.controller.Handler#process(java.lang.Object)
	 */
	public Result process(Object o) throws Exception {
		Map<String, String[]> requestData=(Map<String, String[]>)o;
		PatientDAO pd=DAOFactory.getDAOFactory().getPatientDAO();
		if (requestData.get("searchBy")[0].equals("searchById")){
			PatientDetails patientDetails=pd.getPatientById(Integer.parseInt(requestData.get("searchKey")[0]));
			return new Result("singleRecord", "patientDetails", patientDetails);
		}
		if (requestData.get("searchBy")[0].equals("searchByName")){
			List<PatientDetails> patientDetails=pd.getPatientByName(requestData.get("searchKey")[0]);
			System.out.println("**************** : "+patientDetails.size());
			return new Result("multipleRecords", "patients", patientDetails);
		}
		if (requestData.get("searchBy")[0].equals("searchByLocation")){
			List<PatientDetails> patientDetails=pd.getPatientByLocation(requestData.get("searchKey")[0]);
			return new Result("multipleRecords", "patients", patientDetails);
		}
		return null;
	}

}

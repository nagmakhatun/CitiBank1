/**
 * 
 */
package com.santosh.hospital.handlers;

import java.util.Map;

import com.santosh.hospital.controller.Handler;
import com.santosh.hospital.controller.Result;
import com.santosh.hospital.dao.DAOFactory;
import com.santosh.hospital.dao.MedicationDAO;

/**
 * @author Santosh
 *
 */
public class RemoveMedicationHandler implements Handler {

	/* (non-Javadoc)
	 * @see com.santosh.hospital.controller.Handler#process(java.lang.Object)
	 */
	public Result process(Object o) throws Exception {
		
		Map<String, String[]> requestData=(Map<String, String[]>)o;
		String medicationId=requestData.get("medicationId")[0];
		MedicationDAO dd=DAOFactory.getDAOFactory().getMedicationDAO();
		dd.remove(medicationId);
		return new Result("success");
	}

}

/**
 * 
 */
package com.santosh.hospital.handlers;

import java.util.Map;

import com.santosh.hospital.controller.Handler;
import com.santosh.hospital.controller.Result;
import com.santosh.hospital.dao.DAOFactory;
import com.santosh.hospital.dao.PatientDAO;

/**
 * @author Santosh
 *
 */
public class RemovePatientHandler implements Handler {

	/* (non-Javadoc)
	 * @see com.santosh.hospital.controller.Handler#process(java.lang.Object)
	 */
	public Result process(Object o) throws Exception {
		
		Map<String, String[]> requestData=(Map<String, String[]>)o;
		String patientId=requestData.get("patientId")[0];
		PatientDAO pd=DAOFactory.getDAOFactory().getPatientDAO();
		pd.remove(patientId);
		return new Result("success");
	}

}

/**
 * 
 */
package com.santosh.hospital.handlers;

import com.santosh.hospital.controller.Handler;
import com.santosh.hospital.controller.Result;
import com.santosh.hospital.dao.AdminDetailsDAO;
import com.santosh.hospital.dao.DAOFactory;
import com.santosh.hospital.model.AdminDetails;

/**
 * @author Santosh
 *
 */
public class AdminLoginHandler implements Handler {

	/* (non-Javadoc)
	 * @see com.santosh.hospital.controller.Handler#process(java.lang.Object)
	 */
	public Result process(Object o) throws Exception {
		AdminDetails reqData=(AdminDetails)o;
		
		AdminDetailsDAO adminDAO=DAOFactory.getDAOFactory().getAdminDetailsDAO();
		
		if (adminDAO.find(reqData)){
			return new Result("success");
		}
		return new Result("fail");
	}

}

/**
 * 
 */
package com.santosh.hospital.handlers;

import com.santosh.hospital.controller.Handler;
import com.santosh.hospital.controller.Result;
import com.santosh.hospital.dao.DAOFactory;
import com.santosh.hospital.dao.PatientDAO;
import com.santosh.hospital.model.PatientDetails;

/**
 * @author Santosh
 *
 */
public class AddPatientHandler implements Handler {

	/* (non-Javadoc)
	 * @see com.santosh.hospital.controller.Handler#process(java.lang.Object)
	 */
	public Result process(Object o) throws Exception {
		
		PatientDetails pd=(PatientDetails)o;
		PatientDAO patientDAO=DAOFactory.getDAOFactory().getPatientDAO();
		try{
			patientDAO.createPatient(pd);
		}catch(Exception e){
			e.printStackTrace();
			return new Result("fail");
		}
		return new Result("success");
	}

}

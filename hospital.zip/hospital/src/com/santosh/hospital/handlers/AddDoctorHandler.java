/**
 * 
 */
package com.santosh.hospital.handlers;

import com.santosh.hospital.controller.Handler;
import com.santosh.hospital.controller.Result;
import com.santosh.hospital.dao.DAOFactory;
import com.santosh.hospital.dao.DoctorDAO;
import com.santosh.hospital.model.DoctorDetails;

/**
 * @author Santosh
 *
 */
public class AddDoctorHandler implements Handler {

	/* (non-Javadoc)
	 * @see com.santosh.hospital.controller.Handler#process(java.lang.Object)
	 */
	public Result process(Object o) throws Exception {
		
		DoctorDetails dd=(DoctorDetails)o;
		DoctorDAO doctorDAO=DAOFactory.getDAOFactory().getDoctorDAO();
		doctorDAO.createDoctor(dd);
		return new Result("success");
	}
}

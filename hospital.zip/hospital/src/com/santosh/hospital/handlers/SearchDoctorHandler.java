/**
 * 
 */
package com.santosh.hospital.handlers;

import java.util.List;
import java.util.Map;

import com.santosh.hospital.controller.Handler;
import com.santosh.hospital.controller.Result;
import com.santosh.hospital.dao.DAOFactory;
import com.santosh.hospital.dao.DoctorDAO;
import com.santosh.hospital.model.DoctorDetails;

/**
 * @author Santosh
 *
 */
public class SearchDoctorHandler implements Handler {

	/* (non-Javadoc)
	 * @see com.santosh.hospital.controller.Handler#process(java.lang.Object)
	 */
	public Result process(Object o) throws Exception {
		Map<String, String[]> requestData=(Map<String, String[]>)o;
		DoctorDAO dd=DAOFactory.getDAOFactory().getDoctorDAO();
		if (requestData.get("searchBy")[0].equals("searchById")){
			DoctorDetails doctorDetails=dd.getDoctorById(Integer.parseInt(requestData.get("searchKey")[0]));
			return new Result("singleRecord", "doctorDetails", doctorDetails);
		}
		if (requestData.get("searchBy")[0].equals("searchByName")){
			List<DoctorDetails> doctorDetails=dd.getDoctorByName(requestData.get("searchKey")[0]);
			return new Result("multipleRecords", "doctors", doctorDetails);
		}
		if (requestData.get("searchBy")[0].equals("searchBySpecialization")){
			List<DoctorDetails> doctorDetails=dd.getDoctorBySpecialization(requestData.get("searchKey")[0]);
			return new Result("multipleRecords", "doctors", doctorDetails);
		}
		return null;
	}
}

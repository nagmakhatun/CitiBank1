/**
 * 
 */
package com.santosh.hospital.handlers;

import java.util.List;
import java.util.Map;

import com.santosh.hospital.controller.Handler;
import com.santosh.hospital.controller.Result;
import com.santosh.hospital.dao.DAOFactory;
import com.santosh.hospital.dao.MedicationDAO;
import com.santosh.hospital.model.MedicationDetails;

/**
 * @author Santosh
 *
 */
public class SearchMedicationHandler implements Handler {

	/* (non-Javadoc)
	 * @see com.santosh.hospital.controller.Handler#process(java.lang.Object)
	 */
	public Result process(Object o) throws Exception {
		Map<String, String[]> requestData=(Map<String, String[]>)o;
		MedicationDAO dd=DAOFactory.getDAOFactory().getMedicationDAO();
		if (requestData.get("searchBy")[0].equals("searchById")){
			MedicationDetails medicationDetails=dd.getMedicationById(Integer.parseInt(requestData.get("searchKey")[0]));
			return new Result("singleRecord", "medicationDetails", medicationDetails);
		}
		if (requestData.get("searchBy")[0].equals("searchByName")){
			List<MedicationDetails> medicationDetails=dd.getMedicationByName(requestData.get("searchKey")[0]);
			return new Result("multipleRecords", "medications", medicationDetails);
		}
		return null;
		
	}
}

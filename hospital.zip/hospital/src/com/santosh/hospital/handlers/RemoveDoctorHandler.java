/**
 * 
 */
package com.santosh.hospital.handlers;

import java.util.Map;

import com.santosh.hospital.controller.Handler;
import com.santosh.hospital.controller.Result;
import com.santosh.hospital.dao.DAOFactory;
import com.santosh.hospital.dao.DoctorDAO;

/**
 * @author Santosh
 *
 */
public class RemoveDoctorHandler implements Handler {

	/* (non-Javadoc)
	 * @see com.santosh.hospital.controller.Handler#process(java.lang.Object)
	 */
	public Result process(Object o) throws Exception {
		
		Map<String, String[]> requestData=(Map<String, String[]>)o;
		String doctorId=requestData.get("doctorId")[0];
		DoctorDAO dd=DAOFactory.getDAOFactory().getDoctorDAO();
		dd.remove(doctorId);
		return new Result("success");
	}

}

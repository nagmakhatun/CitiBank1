/**
 * 
 */
package com.santosh.hospital.handlers;

import com.santosh.hospital.controller.Handler;
import com.santosh.hospital.controller.Result;
import com.santosh.hospital.dao.AdminDetailsDAO;
import com.santosh.hospital.dao.DAOFactory;
import com.santosh.hospital.model.AdminDetails;

/**
 * @author Santosh
 *
 */
public class AddAdminHandler implements Handler {

	/* (non-Javadoc)
	 * @see com.santosh.hospital.controller.Handler#process(java.lang.Object)
	 */
	public Result process(Object o) throws Exception {
		
		AdminDetails ad=(AdminDetails)o;
		AdminDetailsDAO adminDetailsDAO=DAOFactory.getDAOFactory().getAdminDetailsDAO();
		adminDetailsDAO.create(ad);
		return new Result("success");
	}
}
